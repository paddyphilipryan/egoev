<?php
/**
 * @link http://craftcms.com/
 * @copyright Copyright (c) Pixel & Tonic, Inc.
 * @license http://craftcms.com/license
 */

namespace craft\behaviors;

use yii\base\Behavior;

/**
 * Custom field behavior
 *
 * This class provides attributes for all the unique custom field handles.
 *
 * @method static logoDark(mixed $value) Sets the [[logoDark]] property
 * @method static logoLight(mixed $value) Sets the [[logoLight]] property
 * @method static contactPhone(mixed $value) Sets the [[contactPhone]] property
 * @method static contactEmail(mixed $value) Sets the [[contactEmail]] property
 * @method static contactAddress(mixed $value) Sets the [[contactAddress]] property
 * @method static footerText(mixed $value) Sets the [[footerText]] property
 * @method static sidebarAbout(mixed $value) Sets the [[sidebarAbout]] property
 * @method static facebook(mixed $value) Sets the [[facebook]] property
 * @method static twitter(mixed $value) Sets the [[twitter]] property
 * @method static instagram(mixed $value) Sets the [[instagram]] property
 * @method static linkedin(mixed $value) Sets the [[linkedin]] property
 * @method static commonExcerpt(mixed $value) Sets the [[commonExcerpt]] property
 * @method static mainContent(mixed $value) Sets the [[mainContent]] property
 * @method static navLinks(mixed $value) Sets the [[navLinks]] property
 * @method static linkText(mixed $value) Sets the [[linkText]] property
 * @method static linkDestination(mixed $value) Sets the [[linkDestination]] property
 * @method static heroWelcome(mixed $value) Sets the [[heroWelcome]] property
 * @method static heroTitle(mixed $value) Sets the [[heroTitle]] property
 * @method static heroCta(mixed $value) Sets the [[heroCta]] property
 * @method static testimonialsTitle(mixed $value) Sets the [[testimonialsTitle]] property
 * @method static testimonials(mixed $value) Sets the [[testimonials]] property
 * @method static comment(mixed $value) Sets the [[comment]] property
 * @method static person(mixed $value) Sets the [[person]] property
 * @method static personImage(mixed $value) Sets the [[personImage]] property
 * @method static personTitle(mixed $value) Sets the [[personTitle]] property
 * @method static sectionImage(mixed $value) Sets the [[sectionImage]] property
 * @method static blogSectionTitle(mixed $value) Sets the [[blogSectionTitle]] property
 * @method static servicesSubtitle(mixed $value) Sets the [[servicesSubtitle]] property
 * @method static servicesTitle(mixed $value) Sets the [[servicesTitle]] property
 * @method static servicesCtaText(mixed $value) Sets the [[servicesCtaText]] property
 * @method static servicesEntries(mixed $value) Sets the [[servicesEntries]] property
 * @method static serviceTextLinkTitle(mixed $value) Sets the [[serviceTextLinkTitle]] property
 * @method static serviceImage(mixed $value) Sets the [[serviceImage]] property
 * @method static serviceLink(mixed $value) Sets the [[serviceLink]] property
 * @method static serviceTitle(mixed $value) Sets the [[serviceTitle]] property
 * @method static serviceDescription(mixed $value) Sets the [[serviceDescription]] property
 * @method static splitImage(mixed $value) Sets the [[splitImage]] property
 * @method static leadHeading(mixed $value) Sets the [[leadHeading]] property
 * @method static leadDescription(mixed $value) Sets the [[leadDescription]] property
 * @method static carBanner(mixed $value) Sets the [[carBanner]] property
 * @method static mainBody(mixed $value) Sets the [[mainBody]] property
 * @method static bottomSectionSubtitle(mixed $value) Sets the [[bottomSectionSubtitle]] property
 * @method static bottomSectionTitle(mixed $value) Sets the [[bottomSectionTitle]] property
 * @method static bottomSectionText(mixed $value) Sets the [[bottomSectionText]] property
 * @method static navMore(mixed $value) Sets the [[navMore]] property
 * @method static navPhone(mixed $value) Sets the [[navPhone]] property
 * @method static footerCopy(mixed $value) Sets the [[footerCopy]] property
 * @method static appTitle(mixed $value) Sets the [[appTitle]] property
 * @method static appMainHeading(mixed $value) Sets the [[appMainHeading]] property
 * @method static appBodyText(mixed $value) Sets the [[appBodyText]] property
 * @method static recentSubtitle(mixed $value) Sets the [[recentSubtitle]] property
 * @method static recentTitle(mixed $value) Sets the [[recentTitle]] property
 * @method static recentCtaText(mixed $value) Sets the [[recentCtaText]] property
 * @method static recentCtaLink(mixed $value) Sets the [[recentCtaLink]] property
 * @method static faqSubtitle(mixed $value) Sets the [[faqSubtitle]] property
 * @method static faqTitle(mixed $value) Sets the [[faqTitle]] property
 * @method static faqMatrix(mixed $value) Sets the [[faqMatrix]] property
 * @method static question(mixed $value) Sets the [[question]] property
 * @method static answer(mixed $value) Sets the [[answer]] property
 * @method static installHeader(mixed $value) Sets the [[installHeader]] property
 * @method static installBody(mixed $value) Sets the [[installBody]] property
 * @method static installBullets(mixed $value) Sets the [[installBullets]] property
 * @method static featuredImage(mixed $value) Sets the [[featuredImage]] property
 * @method static testimonialsSubtitle(mixed $value) Sets the [[testimonialsSubtitle]] property
 * @method static androidAppLink(mixed $value) Sets the [[androidAppLink]] property
 * @method static appIosLink(mixed $value) Sets the [[appIosLink]] property
 * @method static carBrands(mixed $value) Sets the [[carBrands]] property
 * @method static carLogos(mixed $value) Sets the [[carLogos]] property
 * @method static servicesDescription(mixed $value) Sets the [[servicesDescription]] property
 * @method static sectionTitle(mixed $value) Sets the [[sectionTitle]] property
 * @method static serviceTextMain(mixed $value) Sets the [[serviceTextMain]] property
 */
class CustomFieldBehavior extends Behavior
{
    /**
     * @var bool Whether the behavior should provide methods based on the field handles.
     */
    public bool $hasMethods = false;

    /**
     * @var bool Whether properties on the class should be settable directly.
     */
    public bool $canSetProperties = true;

    /**
     * @var string[] List of supported field handles.
     */
    public static $fieldHandles = [
        'logoDark' => true,
        'logoLight' => true,
        'contactPhone' => true,
        'contactEmail' => true,
        'contactAddress' => true,
        'footerText' => true,
        'sidebarAbout' => true,
        'facebook' => true,
        'twitter' => true,
        'instagram' => true,
        'linkedin' => true,
        'commonExcerpt' => true,
        'mainContent' => true,
        'navLinks' => true,
        'linkText' => true,
        'linkDestination' => true,
        'heroWelcome' => true,
        'heroTitle' => true,
        'heroCta' => true,
        'testimonialsTitle' => true,
        'testimonials' => true,
        'comment' => true,
        'person' => true,
        'personImage' => true,
        'personTitle' => true,
        'sectionImage' => true,
        'blogSectionTitle' => true,
        'servicesSubtitle' => true,
        'servicesTitle' => true,
        'servicesCtaText' => true,
        'servicesEntries' => true,
        'serviceTextLinkTitle' => true,
        'serviceImage' => true,
        'serviceLink' => true,
        'serviceTitle' => true,
        'serviceDescription' => true,
        'splitImage' => true,
        'leadHeading' => true,
        'leadDescription' => true,
        'carBanner' => true,
        'mainBody' => true,
        'bottomSectionSubtitle' => true,
        'bottomSectionTitle' => true,
        'bottomSectionText' => true,
        'navMore' => true,
        'navPhone' => true,
        'footerCopy' => true,
        'appTitle' => true,
        'appMainHeading' => true,
        'appBodyText' => true,
        'recentSubtitle' => true,
        'recentTitle' => true,
        'recentCtaText' => true,
        'recentCtaLink' => true,
        'faqSubtitle' => true,
        'faqTitle' => true,
        'faqMatrix' => true,
        'question' => true,
        'answer' => true,
        'installHeader' => true,
        'installBody' => true,
        'installBullets' => true,
        'featuredImage' => true,
        'testimonialsSubtitle' => true,
        'androidAppLink' => true,
        'appIosLink' => true,
        'carBrands' => true,
        'carLogos' => true,
        'servicesDescription' => true,
        'sectionTitle' => true,
        'serviceTextMain' => true,
    ];

    /**
     * @var \craft\elements\db\AssetQuery|\craft\elements\ElementCollection<\craft\elements\Asset> Value for field with the handle “logoDark”.
     */
    public $logoDark;

    /**
     * @var \craft\elements\db\AssetQuery|\craft\elements\ElementCollection<\craft\elements\Asset> Value for field with the handle “logoLight”.
     */
    public $logoLight;

    /**
     * @var string|null Value for field with the handle “contactPhone”.
     */
    public $contactPhone;

    /**
     * @var string|null Value for field with the handle “contactEmail”.
     */
    public $contactEmail;

    /**
     * @var string|null Value for field with the handle “contactAddress”.
     */
    public $contactAddress;

    /**
     * @var string|null Value for field with the handle “footerText”.
     */
    public $footerText;

    /**
     * @var mixed Value for field with the handle “sidebarAbout”.
     */
    public $sidebarAbout;

    /**
     * @var string|null Value for field with the handle “facebook”.
     */
    public $facebook;

    /**
     * @var string|null Value for field with the handle “twitter”.
     */
    public $twitter;

    /**
     * @var string|null Value for field with the handle “instagram”.
     */
    public $instagram;

    /**
     * @var string|null Value for field with the handle “linkedin”.
     */
    public $linkedin;

    /**
     * @var string|null Value for field with the handle “commonExcerpt”.
     */
    public $commonExcerpt;

    /**
     * @var mixed Value for field with the handle “mainContent”.
     */
    public $mainContent;

    /**
     * @var \craft\elements\db\MatrixBlockQuery|\craft\elements\ElementCollection<\craft\elements\MatrixBlock> Value for field with the handle “navLinks”.
     */
    public $navLinks;

    /**
     * @var string|null Value for field with the handle “linkText”.
     */
    public $linkText;

    /**
     * @var \craft\elements\db\EntryQuery|\craft\elements\ElementCollection<\craft\elements\Entry> Value for field with the handle “linkDestination”.
     */
    public $linkDestination;

    /**
     * @var string|null Value for field with the handle “heroWelcome”.
     */
    public $heroWelcome;

    /**
     * @var string|null Value for field with the handle “heroTitle”.
     */
    public $heroTitle;

    /**
     * @var string|null Value for field with the handle “heroCta”.
     */
    public $heroCta;

    /**
     * @var string|null Value for field with the handle “testimonialsTitle”.
     */
    public $testimonialsTitle;

    /**
     * @var \craft\elements\db\MatrixBlockQuery|\craft\elements\ElementCollection<\craft\elements\MatrixBlock> Value for field with the handle “testimonials”.
     */
    public $testimonials;

    /**
     * @var string|null Value for field with the handle “comment”.
     */
    public $comment;

    /**
     * @var string|null Value for field with the handle “person”.
     */
    public $person;

    /**
     * @var \craft\elements\db\AssetQuery|\craft\elements\ElementCollection<\craft\elements\Asset> Value for field with the handle “personImage”.
     */
    public $personImage;

    /**
     * @var string|null Value for field with the handle “personTitle”.
     */
    public $personTitle;

    /**
     * @var \craft\elements\db\AssetQuery|\craft\elements\ElementCollection<\craft\elements\Asset> Value for field with the handle “sectionImage”.
     */
    public $sectionImage;

    /**
     * @var string|null Value for field with the handle “blogSectionTitle”.
     */
    public $blogSectionTitle;

    /**
     * @var string|null Value for field with the handle “servicesSubtitle”.
     */
    public $servicesSubtitle;

    /**
     * @var string|null Value for field with the handle “servicesTitle”.
     */
    public $servicesTitle;

    /**
     * @var string|null Value for field with the handle “servicesCtaText”.
     */
    public $servicesCtaText;

    /**
     * @var \craft\elements\db\MatrixBlockQuery|\craft\elements\ElementCollection<\craft\elements\MatrixBlock> Value for field with the handle “servicesEntries”.
     */
    public $servicesEntries;

    /**
     * @var string|null Value for field with the handle “serviceTextLinkTitle”.
     */
    public $serviceTextLinkTitle;

    /**
     * @var \craft\elements\db\AssetQuery|\craft\elements\ElementCollection<\craft\elements\Asset> Value for field with the handle “serviceImage”.
     */
    public $serviceImage;

    /**
     * @var string|null Value for field with the handle “serviceLink”.
     */
    public $serviceLink;

    /**
     * @var string|null Value for field with the handle “serviceTitle”.
     */
    public $serviceTitle;

    /**
     * @var string|null Value for field with the handle “serviceDescription”.
     */
    public $serviceDescription;

    /**
     * @var \craft\elements\db\AssetQuery|\craft\elements\ElementCollection<\craft\elements\Asset> Value for field with the handle “splitImage”.
     */
    public $splitImage;

    /**
     * @var string|null Value for field with the handle “leadHeading”.
     */
    public $leadHeading;

    /**
     * @var mixed Value for field with the handle “leadDescription”.
     */
    public $leadDescription;

    /**
     * @var \craft\elements\db\AssetQuery|\craft\elements\ElementCollection<\craft\elements\Asset> Value for field with the handle “carBanner”.
     */
    public $carBanner;

    /**
     * @var mixed Value for field with the handle “mainBody”.
     */
    public $mainBody;

    /**
     * @var string|null Value for field with the handle “bottomSectionSubtitle”.
     */
    public $bottomSectionSubtitle;

    /**
     * @var string|null Value for field with the handle “bottomSectionTitle”.
     */
    public $bottomSectionTitle;

    /**
     * @var mixed Value for field with the handle “bottomSectionText”.
     */
    public $bottomSectionText;

    /**
     * @var string|null Value for field with the handle “navMore”.
     */
    public $navMore;

    /**
     * @var string|null Value for field with the handle “navPhone”.
     */
    public $navPhone;

    /**
     * @var string|null Value for field with the handle “footerCopy”.
     */
    public $footerCopy;

    /**
     * @var string|null Value for field with the handle “appTitle”.
     */
    public $appTitle;

    /**
     * @var string|null Value for field with the handle “appMainHeading”.
     */
    public $appMainHeading;

    /**
     * @var mixed Value for field with the handle “appBodyText”.
     */
    public $appBodyText;

    /**
     * @var string|null Value for field with the handle “recentSubtitle”.
     */
    public $recentSubtitle;

    /**
     * @var string|null Value for field with the handle “recentTitle”.
     */
    public $recentTitle;

    /**
     * @var string|null Value for field with the handle “recentCtaText”.
     */
    public $recentCtaText;

    /**
     * @var string|null Value for field with the handle “recentCtaLink”.
     */
    public $recentCtaLink;

    /**
     * @var string|null Value for field with the handle “faqSubtitle”.
     */
    public $faqSubtitle;

    /**
     * @var string|null Value for field with the handle “faqTitle”.
     */
    public $faqTitle;

    /**
     * @var \craft\elements\db\MatrixBlockQuery|\craft\elements\ElementCollection<\craft\elements\MatrixBlock> Value for field with the handle “faqMatrix”.
     */
    public $faqMatrix;

    /**
     * @var string|null Value for field with the handle “question”.
     */
    public $question;

    /**
     * @var mixed Value for field with the handle “answer”.
     */
    public $answer;

    /**
     * @var string|null Value for field with the handle “installHeader”.
     */
    public $installHeader;

    /**
     * @var string|null Value for field with the handle “installBody”.
     */
    public $installBody;

    /**
     * @var mixed Value for field with the handle “installBullets”.
     */
    public $installBullets;

    /**
     * @var \craft\elements\db\AssetQuery|\craft\elements\ElementCollection<\craft\elements\Asset> Value for field with the handle “featuredImage”.
     */
    public $featuredImage;

    /**
     * @var string|null Value for field with the handle “testimonialsSubtitle”.
     */
    public $testimonialsSubtitle;

    /**
     * @var string|null Value for field with the handle “androidAppLink”.
     */
    public $androidAppLink;

    /**
     * @var string|null Value for field with the handle “appIosLink”.
     */
    public $appIosLink;

    /**
     * @var \craft\elements\db\AssetQuery|\craft\elements\ElementCollection<\craft\elements\Asset> Value for field with the handle “carBrands”.
     */
    public $carBrands;

    /**
     * @var \craft\elements\db\MatrixBlockQuery|\craft\elements\ElementCollection<\craft\elements\MatrixBlock> Value for field with the handle “carLogos”.
     */
    public $carLogos;

    /**
     * @var mixed Value for field with the handle “servicesDescription”.
     */
    public $servicesDescription;

    /**
     * @var string|null Value for field with the handle “sectionTitle”.
     */
    public $sectionTitle;

    /**
     * @var string|null Value for field with the handle “serviceTextMain”.
     */
    public $serviceTextMain;

    /**
     * @var array Additional custom field values we don’t know about yet.
     */
    private array $_customFieldValues = [];

    /**
     * @inheritdoc
     */
    public function __call($name, $params)
    {
        if ($this->hasMethods && isset(self::$fieldHandles[$name]) && count($params) === 1) {
            $this->$name = $params[0];
            return $this->owner;
        }
        return parent::__call($name, $params);
    }

    /**
     * @inheritdoc
     */
    public function hasMethod($name): bool
    {
        if ($this->hasMethods && isset(self::$fieldHandles[$name])) {
            return true;
        }
        return parent::hasMethod($name);
    }

    /**
     * @inheritdoc
     */
    public function __isset($name): bool
    {
        if (isset(self::$fieldHandles[$name])) {
            return true;
        }
        return parent::__isset($name);
    }

    /**
     * @inheritdoc
     */
    public function __get($name)
    {
        if (isset(self::$fieldHandles[$name])) {
            return $this->_customFieldValues[$name] ?? null;
        }
        return parent::__get($name);
    }

    /**
     * @inheritdoc
     */
    public function __set($name, $value)
    {
        if (isset(self::$fieldHandles[$name])) {
            $this->_customFieldValues[$name] = $value;
            return;
        }
        parent::__set($name, $value);
    }

    /**
     * @inheritdoc
     */
    public function canGetProperty($name, $checkVars = true): bool
    {
        if ($checkVars && isset(self::$fieldHandles[$name])) {
            return true;
        }
        return parent::canGetProperty($name, $checkVars);
    }

    /**
     * @inheritdoc
     */
    public function canSetProperty($name, $checkVars = true): bool
    {
        if (!$this->canSetProperties) {
            return false;
        }
        if ($checkVars && isset(self::$fieldHandles[$name])) {
            return true;
        }
        return parent::canSetProperty($name, $checkVars);
    }
}

<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _layouts/cp */
class __TwigTemplate_0c480fd31058974e08eca9afa409398071e3d4b2aa5433f7fd7bcfaea66618c9 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
            'mainFormAttributes' => [$this, 'block_mainFormAttributes'],
            'header' => [$this, 'block_header'],
            'pageTitle' => [$this, 'block_pageTitle'],
            'main' => [$this, 'block_main'],
            'content' => [$this, 'block_content'],
            'actionButton' => [$this, 'block_actionButton'],
            'submitButton' => [$this, 'block_submitButton'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 42
        return "_layouts/basecp.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_layouts/cp");
        // line 45
        $context["queue"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 45, $this->source); })()), "app", []), "queue", []);
        // line 46
        ob_start();
        // line 47
        echo "    ";
        if ($this->env->getTest('instance of')->getCallable()((isset($context["queue"]) || array_key_exists("queue", $context) ? $context["queue"] : (function () { throw new RuntimeError('Variable "queue" does not exist.', 47, $this->source); })()), "craft\\queue\\QueueInterface")) {
            // line 48
            echo "        Craft.cp.setJobInfo(";
            echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["queue"]) || array_key_exists("queue", $context) ? $context["queue"] : (function () { throw new RuntimeError('Variable "queue" does not exist.', 48, $this->source); })()), "getJobInfo", [0 => 100], "method"));
            echo ", false);
        ";
            // line 49
            if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["queue"]) || array_key_exists("queue", $context) ? $context["queue"] : (function () { throw new RuntimeError('Variable "queue" does not exist.', 49, $this->source); })()), "getHasReservedJobs", [], "method")) {
                // line 50
                echo "            Craft.cp.trackJobProgress(true);
        ";
            } elseif (craft\helpers\Template::attribute($this->env, $this->source,             // line 51
(isset($context["queue"]) || array_key_exists("queue", $context) ? $context["queue"] : (function () { throw new RuntimeError('Variable "queue" does not exist.', 51, $this->source); })()), "getHasWaitingJobs", [], "method")) {
                // line 52
                echo "            Craft.cp.runQueue();
        ";
            }
            // line 54
            echo "    ";
        } else {
            // line 55
            echo "        Craft.cp.enableQueue = false;
    ";
        }
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        // line 59
        $context["hasSystemIcon"] = (((isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 59, $this->source); })()) == (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 59, $this->source); })())) && craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 59, $this->source); })()), "rebrand", []), "isIconUploaded", []));
        // line 60
        $context["fullPageForm"] = (array_key_exists("fullPageForm", $context) && (isset($context["fullPageForm"]) || array_key_exists("fullPageForm", $context) ? $context["fullPageForm"] : (function () { throw new RuntimeError('Variable "fullPageForm" does not exist.', 60, $this->source); })()));
        // line 62
        $context["editionName"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 62, $this->source); })()), "app", []), "getEditionName", [], "method");
        // line 63
        $context["canUpgradeEdition"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 63, $this->source); })()), "app", []), "getCanUpgradeEdition", [], "method");
        // line 64
        $context["licensedEdition"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 64, $this->source); })()), "app", []), "getLicensedEdition", [], "method");
        // line 65
        $context["isTrial"] = ( !((isset($context["licensedEdition"]) || array_key_exists("licensedEdition", $context) ? $context["licensedEdition"] : (function () { throw new RuntimeError('Variable "licensedEdition" does not exist.', 65, $this->source); })()) === null) &&  !((isset($context["licensedEdition"]) || array_key_exists("licensedEdition", $context) ? $context["licensedEdition"] : (function () { throw new RuntimeError('Variable "licensedEdition" does not exist.', 65, $this->source); })()) === (isset($context["CraftEdition"]) || array_key_exists("CraftEdition", $context) ? $context["CraftEdition"] : (function () { throw new RuntimeError('Variable "CraftEdition" does not exist.', 65, $this->source); })())));
        // line 67
        $context["contentNotice"] = twig_trim_filter((($context["contentNotice"]) ?? (((        $this->hasBlock("contentNotice", $context, $blocks)) ? (        $this->renderBlock("contentNotice", $context, $blocks)) : ("")))));
        // line 68
        $context["sidebar"] = twig_trim_filter((($context["sidebar"]) ?? (((        $this->hasBlock("sidebar", $context, $blocks)) ? (        $this->renderBlock("sidebar", $context, $blocks)) : ("")))));
        // line 69
        $context["contextMenu"] = twig_trim_filter((($context["contextMenu"]) ?? (((        $this->hasBlock("contextMenu", $context, $blocks)) ? (        $this->renderBlock("contextMenu", $context, $blocks)) : ("")))));
        // line 70
        $context["toolbar"] = twig_trim_filter((($context["toolbar"]) ?? (((        $this->hasBlock("toolbar", $context, $blocks)) ? (        $this->renderBlock("toolbar", $context, $blocks)) : ("")))));
        // line 71
        $context["actionButton"] = twig_trim_filter(((        $this->hasBlock("actionButton", $context, $blocks)) ? (        $this->renderBlock("actionButton", $context, $blocks)) : ("")));
        // line 72
        $context["additionalButtons"] = (($context["additionalButtons"]) ?? (null));
        // line 73
        $context["details"] = twig_trim_filter((($context["details"]) ?? (((        $this->hasBlock("details", $context, $blocks)) ? (        $this->renderBlock("details", $context, $blocks)) : ("")))));
        // line 74
        $context["footer"] = twig_trim_filter((($context["footer"]) ?? (((        $this->hasBlock("footer", $context, $blocks)) ? (        $this->renderBlock("footer", $context, $blocks)) : ("")))));
        // line 75
        $context["crumbs"] = (($context["crumbs"]) ?? (null));
        // line 76
        $context["tabs"] = ((($this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (($context["tabs"]) ?? ([]))) > 1)) ? ((isset($context["tabs"]) || array_key_exists("tabs", $context) ? $context["tabs"] : (function () { throw new RuntimeError('Variable "tabs" does not exist.', 76, $this->source); })())) : (null));
        // line 78
        $context["mainContentClasses"] = $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => ((        // line 79
(isset($context["sidebar"]) || array_key_exists("sidebar", $context) ? $context["sidebar"] : (function () { throw new RuntimeError('Variable "sidebar" does not exist.', 79, $this->source); })())) ? ("has-sidebar") : ("")), 1 => ((        // line 80
(isset($context["details"]) || array_key_exists("details", $context) ? $context["details"] : (function () { throw new RuntimeError('Variable "details" does not exist.', 80, $this->source); })())) ? ("has-details") : (""))]);
        // line 83
        $context["bodyClass"] = craft\helpers\Html::explodeClass((($context["bodyClass"]) ?? ([])));
        // line 84
        $context["showHeader"] = (($context["showHeader"]) ?? (true));
        // line 85
        if ( !(isset($context["showHeader"]) || array_key_exists("showHeader", $context) ? $context["showHeader"] : (function () { throw new RuntimeError('Variable "showHeader" does not exist.', 85, $this->source); })())) {
            // line 86
            $context["bodyClass"] = $this->extensions['craft\web\twig\Extension']->pushFilter((isset($context["bodyClass"]) || array_key_exists("bodyClass", $context) ? $context["bodyClass"] : (function () { throw new RuntimeError('Variable "bodyClass" does not exist.', 86, $this->source); })()), "no-header");
        }
        // line 88
        if (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 88, $this->source); })()), "app", []), "hasModule", [0 => "debug"], "method")) {
            // line 89
            $context["bodyClass"] = $this->extensions['craft\web\twig\Extension']->pushFilter((isset($context["bodyClass"]) || array_key_exists("bodyClass", $context) ? $context["bodyClass"] : (function () { throw new RuntimeError('Variable "bodyClass" does not exist.', 89, $this->source); })()), "has-debug-toolbar");
        }
        // line 92
        $context["mainAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" => "main", "role" => "main"], ((        // line 95
$context["mainAttributes"]) ?? ([])));
        // line 97
        $context["formActions"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 97, $this->source); })()), "cp", []), "prepFormActions", [0 => (($context["formActions"]) ?? (null))], "method");
        // line 99
        $context["mainFormAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["id" => "main-form", "method" => "post", "accept-charset" => "UTF-8", "novalidate" => true, "data" => ["saveshortcut" => ((        // line 105
$context["saveShortcut"]) ?? (true)), "saveshortcut-redirect" => ((((        // line 106
$context["saveShortcutRedirect"]) ?? (false))) ? ($this->env->getFilter('hash')->getCallable()((isset($context["saveShortcutRedirect"]) || array_key_exists("saveShortcutRedirect", $context) ? $context["saveShortcutRedirect"] : (function () { throw new RuntimeError('Variable "saveShortcutRedirect" does not exist.', 106, $this->source); })()))) : (false)), "saveshortcut-scroll" => ((        // line 107
$context["retainScrollOnSaveShortcut"]) ?? (false)), "actions" => ((        // line 108
$context["formActions"]) ?? (false)), "confirm-unload" => true, "delta" => craft\helpers\Template::attribute($this->env, $this->source,         // line 110
(isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 110, $this->source); })()), "getIsDeltaRegistrationActive", [], "method"), "delta-names" => craft\helpers\Template::attribute($this->env, $this->source,         // line 111
(isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 111, $this->source); })()), "getDeltaNames", [], "method"), "initial-delta-values" => craft\helpers\Template::attribute($this->env, $this->source,         // line 112
(isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 112, $this->source); })()), "getInitialDeltaValues", [], "method"), "modified-delta-names" => (((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,         // line 113
($context["craft"] ?? null), "app", [], "any", false, true), "request", [], "any", false, true), "getBodyParam", [0 => "modifiedDeltaNames"], "method", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["craft"] ?? null), "app", [], "any", false, true), "request", [], "any", false, true), "getBodyParam", [0 => "modifiedDeltaNames"], "method")))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["craft"] ?? null), "app", [], "any", false, true), "request", [], "any", false, true), "getBodyParam", [0 => "modifiedDeltaNames"], "method")) : ([]))]], ((        // line 115
$context["mainFormAttributes"]) ?? ([])), true);
        // line 117
        ob_start();
        // line 118
        echo "    <div class=\"header-photo\">
        ";
        // line 119
        echo $this->extensions['craft\web\twig\Extension']->tagFunction("img", ["width" => 30, "height" => 30, "sizes" => "30px", "srcset" => (((craft\helpers\Template::attribute($this->env, $this->source,         // line 123
(isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 123, $this->source); })()), "getThumbUrl", [0 => 30], "method") . " 30w, ") . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 123, $this->source); })()), "getThumbUrl", [0 => 60], "method")) . " 60w"), "alt" => craft\helpers\Template::attribute($this->env, $this->source,         // line 124
(isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 124, $this->source); })()), "getThumbAlt", [], "method")]);
        // line 125
        echo "
    </div>
";
        $context["userPhoto"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 129
        ob_start();
        // line 130
        echo "    // Remove the hash so the browser doesn't scroll to it
    window.LOCATION_HASH = document.location.hash ? decodeURIComponent(document.location.hash.substr(1)) : null;
    history.replaceState(undefined, undefined, window.location.href.match(/^[^#]*/)[0]);
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 1]);
        // line 345
        if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 345, $this->source); })()), "can", [0 => "performUpdates"], "method") &&  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 345, $this->source); })()), "app", []), "updates", []), "getIsUpdateInfoCached", [], "method"))) {
            // line 346
            ob_start();
            // line 347
            echo "        Craft.cp.checkForUpdates();
    ";
            craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        }
        // line 42
        $this->parent = $this->loadTemplate("_layouts/basecp.twig", "_layouts/cp", 42);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "_layouts/cp");
    }

    // line 135
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "body");
        // line 136
        echo "    ";
        echo $this->extensions['craft\web\twig\Extension']->tagFunction("a", ["id" => "global-skip-link", "text" => $this->extensions['craft\web\twig\Extension']->translateFilter("Skip to content", "app"), "href" => "#main", "class" => "skip-link btn"]);
        // line 141
        echo "

    <div id=\"global-container\">
        ";
        // line 144
        $this->loadTemplate("_layouts/components/global-sidebar", "_layouts/cp", 144)->display($context);
        // line 145
        echo "
        <div id=\"page-container\">
            ";
        // line 147
        $this->loadTemplate("_layouts/components/alerts", "_layouts/cp", 147)->display($context);
        // line 148
        echo "
            <div id=\"global-header\" role=\"region\" aria-label=\"";
        // line 149
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("My Account", "app"), "html", null, true);
        echo "\">
                <div class=\"flex\">
                    ";
        // line 151
        $this->loadTemplate("_layouts/components/crumbs", "_layouts/cp", 151)->display($context);
        // line 152
        echo "                    <div class=\"flex-grow\"></div>
                    <button type=\"button\" id=\"announcements-btn\" class=\"btn hidden\" title=\"";
        // line 153
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("What’s New", "app"), "html", null, true);
        echo "\">
                        <span class=\"visually-hidden\">";
        // line 154
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("What’s New", "app"), "html", null, true);
        echo "</span>
                        ";
        // line 155
        echo $this->extensions['craft\web\twig\Extension']->svgFunction("@app/icons/gift.svg");
        echo "
                    </button>

                    ";
        // line 159
        echo "                    <div class=\"account-toggle-wrapper\">
                        <button
                            id=\"user-info\"
                            aria-controls=\"account-menu\"
                            class=\"btn menu-toggle\"
                            aria-label=\"";
        // line 164
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("My Account", "app"), "html", null, true);
        echo "\"
                            title=\"";
        // line 165
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("My Account", "app"), "html", null, true);
        echo "\"
                            data-disclosure-trigger>
                            ";
        // line 167
        echo twig_escape_filter($this->env, (isset($context["userPhoto"]) || array_key_exists("userPhoto", $context) ? $context["userPhoto"] : (function () { throw new RuntimeError('Variable "userPhoto" does not exist.', 167, $this->source); })()), "html", null, true);
        echo "
                        </button>
                        <div id=\"account-menu\" class=\"menu menu--disclosure\" data-align=\"right\" data-align-to=\".header-photo\">
                            <ul>
                                <li>
                                    <a href=\"";
        // line 172
        echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url("myaccount"), "html", null, true);
        echo "\" class=\"flex flex-nowrap\">
                                        ";
        // line 173
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 173, $this->source); })()), "photoId", [])) {
            // line 174
            echo "                                            ";
            echo twig_escape_filter($this->env, (isset($context["userPhoto"]) || array_key_exists("userPhoto", $context) ? $context["userPhoto"] : (function () { throw new RuntimeError('Variable "userPhoto" does not exist.', 174, $this->source); })()), "html", null, true);
            echo "
                                        ";
        }
        // line 176
        echo "                                        <div class=\"flex-grow\">
                                            <div>";
        // line 177
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 177, $this->source); })()), "username", []), "html", null, true);
        echo "</div>
                                            ";
        // line 178
        if ( !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 178, $this->source); })()), "app", []), "config", []), "general", []), "useEmailAsUsername", [])) {
            // line 179
            echo "                                                <div class=\"smalltext\">";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 179, $this->source); })()), "email", []), "html", null, true);
            echo "</div>
                                            ";
        }
        // line 181
        echo "                                        </div>
                                    </a>
                                </li>
                            </ul>
                            <hr>
                            <ul>
                                <li><a href=\"";
        // line 187
        echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url("logout"), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Sign out", "app"), "html", null, true);
        echo "</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div id=\"main-container\">
                <main ";
        // line 195
        echo craft\helpers\Html::renderTagAttributes((isset($context["mainAttributes"]) || array_key_exists("mainAttributes", $context) ? $context["mainAttributes"] : (function () { throw new RuntimeError('Variable "mainAttributes" does not exist.', 195, $this->source); })()));
        echo ">

                    ";
        // line 197
        if ((isset($context["fullPageForm"]) || array_key_exists("fullPageForm", $context) ? $context["fullPageForm"] : (function () { throw new RuntimeError('Variable "fullPageForm" does not exist.', 197, $this->source); })())) {
            // line 198
            echo "<form ";
            $this->displayBlock('mainFormAttributes', $context, $blocks);
            echo ">";
            // line 199
            echo craft\helpers\Html::csrfInput();
        }
        // line 201
        echo "
                    ";
        // line 202
        if ((isset($context["showHeader"]) || array_key_exists("showHeader", $context) ? $context["showHeader"] : (function () { throw new RuntimeError('Variable "showHeader" does not exist.', 202, $this->source); })())) {
            // line 203
            echo "                        <div id=\"header-container\">
                            <header id=\"header\">
                                ";
            // line 205
            $this->displayBlock('header', $context, $blocks);
            // line 226
            echo "                            </header><!-- #header -->
                        </div>
                    ";
        }
        // line 229
        echo "
                    <div id=\"main-content\" class=\"";
        // line 230
        echo twig_escape_filter($this->env, twig_join_filter((isset($context["mainContentClasses"]) || array_key_exists("mainContentClasses", $context) ? $context["mainContentClasses"] : (function () { throw new RuntimeError('Variable "mainContentClasses" does not exist.', 230, $this->source); })()), " "), "html", null, true);
        echo "\">
                        ";
        // line 232
        echo "                        ";
        if ((isset($context["sidebar"]) || array_key_exists("sidebar", $context) ? $context["sidebar"] : (function () { throw new RuntimeError('Variable "sidebar" does not exist.', 232, $this->source); })())) {
            // line 233
            echo "                            <div id=\"sidebar-toggle-container\">
                                <button type=\"button\" id=\"sidebar-toggle\" class=\"btn menubtn\" aria-controls=\"sidebar-container\" aria-expanded=\"false\">
                                    ";
            // line 235
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Show sidebar", "app"), "html", null, true);
            echo "
                                </button>
                            </div>
                            <div id=\"sidebar-container\">
                                <div id=\"sidebar\" class=\"sidebar\">
                                    ";
            // line 240
            echo (isset($context["sidebar"]) || array_key_exists("sidebar", $context) ? $context["sidebar"] : (function () { throw new RuntimeError('Variable "sidebar" does not exist.', 240, $this->source); })());
            echo "
                                </div>
                            </div>
                        ";
        }
        // line 244
        echo "
                        ";
        // line 246
        echo "                        <div id=\"content-container\">
                            ";
        // line 247
        if ((isset($context["sidebar"]) || array_key_exists("sidebar", $context) ? $context["sidebar"] : (function () { throw new RuntimeError('Variable "sidebar" does not exist.', 247, $this->source); })())) {
            // line 248
            echo "                                <h2 id=\"content-heading\"></h2>
                            ";
        }
        // line 250
        echo "                            ";
        $this->displayBlock('main', $context, $blocks);
        // line 281
        echo "                        </div><!-- #content-container -->

                        ";
        // line 283
        if ( !twig_test_empty((isset($context["details"]) || array_key_exists("details", $context) ? $context["details"] : (function () { throw new RuntimeError('Variable "details" does not exist.', 283, $this->source); })()))) {
            // line 284
            echo "                            <div id=\"details-container\">
                                <div id=\"details\">
                                    <div class=\"details\">
                                        ";
            // line 287
            echo (isset($context["details"]) || array_key_exists("details", $context) ? $context["details"] : (function () { throw new RuntimeError('Variable "details" does not exist.', 287, $this->source); })());
            echo "
                                    </div>
                                </div>
                            </div>
                        ";
        }
        // line 292
        echo "                    </div><!-- #main-content -->

                    ";
        // line 294
        if ((isset($context["fullPageForm"]) || array_key_exists("fullPageForm", $context) ? $context["fullPageForm"] : (function () { throw new RuntimeError('Variable "fullPageForm" does not exist.', 294, $this->source); })())) {
            // line 295
            echo "</form><!-- #main-form -->";
        }
        // line 297
        echo "                </main><!-- #main -->
            </div><!-- #main-container -->

            <footer id=\"global-footer\">
                ";
        // line 301
        $context["fullEditionName"] = ($this->extensions['craft\web\twig\Extension']->translateFilter("{edition} edition", "app", ["edition" => (isset($context["editionName"]) || array_key_exists("editionName", $context) ? $context["editionName"] : (function () { throw new RuntimeError('Variable "editionName" does not exist.', 301, $this->source); })())]) . (((isset($context["isTrial"]) || array_key_exists("isTrial", $context) ? $context["isTrial"] : (function () { throw new RuntimeError('Variable "isTrial" does not exist.', 301, $this->source); })())) ? ((" " . $this->extensions['craft\web\twig\Extension']->translateFilter("(trial)", "app"))) : ("")));
        // line 302
        echo "                <div id=\"edition-logo\" title=\"";
        echo twig_escape_filter($this->env, (isset($context["fullEditionName"]) || array_key_exists("fullEditionName", $context) ? $context["fullEditionName"] : (function () { throw new RuntimeError('Variable "fullEditionName" does not exist.', 302, $this->source); })()), "html", null, true);
        echo "\">
                    <div class=\"edition-name\" aria-hidden=\"true\">";
        // line 303
        echo twig_escape_filter($this->env, (isset($context["editionName"]) || array_key_exists("editionName", $context) ? $context["editionName"] : (function () { throw new RuntimeError('Variable "editionName" does not exist.', 303, $this->source); })()), "html", null, true);
        echo "</div>
                    ";
        // line 304
        echo $this->extensions['craft\web\twig\Extension']->tagFunction("span", ["class" => "visually-hidden", "text" =>         // line 306
(isset($context["fullEditionName"]) || array_key_exists("fullEditionName", $context) ? $context["fullEditionName"] : (function () { throw new RuntimeError('Variable "fullEditionName" does not exist.', 306, $this->source); })())]);
        // line 307
        echo "
                    ";
        // line 308
        if ((isset($context["isTrial"]) || array_key_exists("isTrial", $context) ? $context["isTrial"] : (function () { throw new RuntimeError('Variable "isTrial" does not exist.', 308, $this->source); })())) {
            // line 309
            echo "                        <div class=\"edition-trial\">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Trial", "app"), "html", null, true);
            echo "</div>
                    ";
        }
        // line 311
        echo "                </div>
                <div id=\"app-info\">
                    <span>Craft CMS ";
        // line 313
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 313, $this->source); })()), "app", []), "version", []), "html", null, true);
        echo "</span>
                    ";
        // line 314
        if ((isset($context["canUpgradeEdition"]) || array_key_exists("canUpgradeEdition", $context) ? $context["canUpgradeEdition"] : (function () { throw new RuntimeError('Variable "canUpgradeEdition" does not exist.', 314, $this->source); })())) {
            // line 315
            echo "                        ";
            $context["linkText"] = (((isset($context["isTrial"]) || array_key_exists("isTrial", $context) ? $context["isTrial"] : (function () { throw new RuntimeError('Variable "isTrial" does not exist.', 315, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Buy Craft Pro", "app")) : ($this->extensions['craft\web\twig\Extension']->translateFilter("Upgrade to Craft Pro", "app")));
            // line 316
            echo "                        <span>
                            <a class=\"go\" href=\"";
            // line 317
            echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url("plugin-store/upgrade-craft"), "html", null, true);
            echo "\" aria-label=\"";
            echo twig_escape_filter($this->env, (isset($context["linkText"]) || array_key_exists("linkText", $context) ? $context["linkText"] : (function () { throw new RuntimeError('Variable "linkText" does not exist.', 317, $this->source); })()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["linkText"]) || array_key_exists("linkText", $context) ? $context["linkText"] : (function () { throw new RuntimeError('Variable "linkText" does not exist.', 317, $this->source); })()), "html", null, true);
            echo "</a>
                        </span>
                    ";
        }
        // line 320
        echo "                </div>
            </footer>

        </div><!-- #page-container -->
    </div><!-- #global-container -->

    ";
        // line 326
        $this->loadTemplate("_layouts/components/notifications", "_layouts/cp", 326)->display($context);
        craft\helpers\Template::endProfile("block", "body");
    }

    // line 198
    public function block_mainFormAttributes($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "mainFormAttributes");
        echo craft\helpers\Html::renderTagAttributes((isset($context["mainFormAttributes"]) || array_key_exists("mainFormAttributes", $context) ? $context["mainFormAttributes"] : (function () { throw new RuntimeError('Variable "mainFormAttributes" does not exist.', 198, $this->source); })()));
        craft\helpers\Template::endProfile("block", "mainFormAttributes");
    }

    // line 205
    public function block_header($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "header");
        // line 206
        echo "                                    <div id=\"page-title\" class=\"flex";
        if ((isset($context["toolbar"]) || array_key_exists("toolbar", $context) ? $context["toolbar"] : (function () { throw new RuntimeError('Variable "toolbar" does not exist.', 206, $this->source); })())) {
            echo " has-toolbar";
        }
        echo "\">
                                        ";
        // line 207
        $this->displayBlock('pageTitle', $context, $blocks);
        // line 212
        echo "                                        ";
        echo (isset($context["contextMenu"]) || array_key_exists("contextMenu", $context) ? $context["contextMenu"] : (function () { throw new RuntimeError('Variable "contextMenu" does not exist.', 212, $this->source); })());
        echo "
                                    </div>
                                    ";
        // line 214
        if ((isset($context["toolbar"]) || array_key_exists("toolbar", $context) ? $context["toolbar"] : (function () { throw new RuntimeError('Variable "toolbar" does not exist.', 214, $this->source); })())) {
            // line 215
            echo "                                        <div id=\"toolbar\" class=\"flex\">
                                            ";
            // line 216
            echo (isset($context["toolbar"]) || array_key_exists("toolbar", $context) ? $context["toolbar"] : (function () { throw new RuntimeError('Variable "toolbar" does not exist.', 216, $this->source); })());
            echo "
                                        </div>
                                    ";
        }
        // line 219
        echo "                                    ";
        if (((isset($context["actionButton"]) || array_key_exists("actionButton", $context) ? $context["actionButton"] : (function () { throw new RuntimeError('Variable "actionButton" does not exist.', 219, $this->source); })()) || (isset($context["additionalButtons"]) || array_key_exists("additionalButtons", $context) ? $context["additionalButtons"] : (function () { throw new RuntimeError('Variable "additionalButtons" does not exist.', 219, $this->source); })()))) {
            // line 220
            echo "                                        <div id=\"action-buttons\" class=\"flex\">
                                            ";
            // line 221
            echo (isset($context["additionalButtons"]) || array_key_exists("additionalButtons", $context) ? $context["additionalButtons"] : (function () { throw new RuntimeError('Variable "additionalButtons" does not exist.', 221, $this->source); })());
            echo "
                                            ";
            // line 222
            echo (isset($context["actionButton"]) || array_key_exists("actionButton", $context) ? $context["actionButton"] : (function () { throw new RuntimeError('Variable "actionButton" does not exist.', 222, $this->source); })());
            echo "
                                        </div>
                                    ";
        }
        // line 225
        echo "                                ";
        craft\helpers\Template::endProfile("block", "header");
    }

    // line 207
    public function block_pageTitle($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "pageTitle");
        // line 208
        echo "                                            ";
        if ((array_key_exists("title", $context) && $this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 208, $this->source); })())))) {
            // line 209
            echo "                                                <h1 class=\"screen-title\" title=\"";
            echo twig_escape_filter($this->env, (isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 209, $this->source); })()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 209, $this->source); })()), "html", null, true);
            echo "</h1>
                                            ";
        }
        // line 211
        echo "                                        ";
        craft\helpers\Template::endProfile("block", "pageTitle");
    }

    // line 250
    public function block_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "main");
        // line 251
        echo "                                <div id=\"content\" class=\"content-pane\">
                                    ";
        // line 252
        if (((isset($context["contentNotice"]) || array_key_exists("contentNotice", $context) ? $context["contentNotice"] : (function () { throw new RuntimeError('Variable "contentNotice" does not exist.', 252, $this->source); })()) || (isset($context["tabs"]) || array_key_exists("tabs", $context) ? $context["tabs"] : (function () { throw new RuntimeError('Variable "tabs" does not exist.', 252, $this->source); })()))) {
            // line 253
            echo "                                        <header id=\"content-header\" class=\"pane-header\">
                                            ";
            // line 254
            echo (((isset($context["contentNotice"]) || array_key_exists("contentNotice", $context) ? $context["contentNotice"] : (function () { throw new RuntimeError('Variable "contentNotice" does not exist.', 254, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->tagFunction("div", ["id" => "content-notice", "html" =>             // line 256
(isset($context["contentNotice"]) || array_key_exists("contentNotice", $context) ? $context["contentNotice"] : (function () { throw new RuntimeError('Variable "contentNotice" does not exist.', 256, $this->source); })()), "role" => "status"])) : (""));
            // line 258
            echo "
                                            ";
            // line 259
            if ((isset($context["tabs"]) || array_key_exists("tabs", $context) ? $context["tabs"] : (function () { throw new RuntimeError('Variable "tabs" does not exist.', 259, $this->source); })())) {
                // line 260
                echo "                                                ";
                $this->loadTemplate("_includes/tabs", "_layouts/cp", 260)->display(twig_array_merge($context, ["containerAttributes" => ["id" => "tabs"]]));
                // line 265
                echo "                                            ";
            }
            // line 266
            echo "                                        </header>
                                    ";
        }
        // line 268
        echo "
                                    ";
        // line 269
        $this->displayBlock('content', $context, $blocks);
        // line 272
        echo "
                                    ";
        // line 274
        echo "                                    ";
        if ((isset($context["footer"]) || array_key_exists("footer", $context) ? $context["footer"] : (function () { throw new RuntimeError('Variable "footer" does not exist.', 274, $this->source); })())) {
            // line 275
            echo "                                        <div id=\"footer\" class=\"flex flex-justify\">
                                            ";
            // line 276
            echo (isset($context["footer"]) || array_key_exists("footer", $context) ? $context["footer"] : (function () { throw new RuntimeError('Variable "footer" does not exist.', 276, $this->source); })());
            echo "
                                        </div>
                                    ";
        }
        // line 279
        echo "                                </div>
                            ";
        craft\helpers\Template::endProfile("block", "main");
    }

    // line 269
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 270
        echo "                                        ";
        echo ((array_key_exists("content", $context)) ? ((isset($context["content"]) || array_key_exists("content", $context) ? $context["content"] : (function () { throw new RuntimeError('Variable "content" does not exist.', 270, $this->source); })())) : (""));
        echo "
                                    ";
        craft\helpers\Template::endProfile("block", "content");
    }

    // line 330
    public function block_actionButton($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 331
        echo "    ";
        if ((isset($context["fullPageForm"]) || array_key_exists("fullPageForm", $context) ? $context["fullPageForm"] : (function () { throw new RuntimeError('Variable "fullPageForm" does not exist.', 331, $this->source); })())) {
            // line 332
            echo "        <div class=\"btngroup\">
            ";
            // line 333
            $this->displayBlock('submitButton', $context, $blocks);
            // line 336
            echo "            ";
            if ((($context["formActions"]) ?? (false))) {
                // line 337
                echo "                <button type=\"button\" class=\"btn submit menubtn\" aria-label=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("More actions", "app"), "html", null, true);
                echo "\"></button>
                ";
                // line 338
                $this->loadTemplate("_layouts/components/form-action-menu", "_layouts/cp", 338)->display($context);
                // line 339
                echo "            ";
            }
            // line 340
            echo "        </div>
    ";
        }
        craft\helpers\Template::endProfile("block", "actionButton");
    }

    // line 333
    public function block_submitButton($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "submitButton");
        // line 334
        echo "                <button type=\"submit\" class=\"btn submit\">";
        echo twig_escape_filter($this->env, (($context["submitButtonLabel"]) ?? ($this->extensions['craft\web\twig\Extension']->translateFilter("Save", "app"))), "html", null, true);
        echo "</button>
            ";
        craft\helpers\Template::endProfile("block", "submitButton");
    }

    public function getTemplateName()
    {
        return "_layouts/cp";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  666 => 334,  661 => 333,  654 => 340,  651 => 339,  649 => 338,  644 => 337,  641 => 336,  639 => 333,  636 => 332,  633 => 331,  628 => 330,  620 => 270,  615 => 269,  609 => 279,  603 => 276,  600 => 275,  597 => 274,  594 => 272,  592 => 269,  589 => 268,  585 => 266,  582 => 265,  579 => 260,  577 => 259,  574 => 258,  572 => 256,  571 => 254,  568 => 253,  566 => 252,  563 => 251,  558 => 250,  553 => 211,  545 => 209,  542 => 208,  537 => 207,  532 => 225,  526 => 222,  522 => 221,  519 => 220,  516 => 219,  510 => 216,  507 => 215,  505 => 214,  499 => 212,  497 => 207,  490 => 206,  485 => 205,  476 => 198,  471 => 326,  463 => 320,  453 => 317,  450 => 316,  447 => 315,  445 => 314,  441 => 313,  437 => 311,  431 => 309,  429 => 308,  426 => 307,  424 => 306,  423 => 304,  419 => 303,  414 => 302,  412 => 301,  406 => 297,  403 => 295,  401 => 294,  397 => 292,  389 => 287,  384 => 284,  382 => 283,  378 => 281,  375 => 250,  371 => 248,  369 => 247,  366 => 246,  363 => 244,  356 => 240,  348 => 235,  344 => 233,  341 => 232,  337 => 230,  334 => 229,  329 => 226,  327 => 205,  323 => 203,  321 => 202,  318 => 201,  315 => 199,  311 => 198,  309 => 197,  304 => 195,  291 => 187,  283 => 181,  277 => 179,  275 => 178,  271 => 177,  268 => 176,  262 => 174,  260 => 173,  256 => 172,  248 => 167,  243 => 165,  239 => 164,  232 => 159,  226 => 155,  222 => 154,  218 => 153,  215 => 152,  213 => 151,  208 => 149,  205 => 148,  203 => 147,  199 => 145,  197 => 144,  192 => 141,  189 => 136,  184 => 135,  178 => 42,  173 => 347,  171 => 346,  169 => 345,  163 => 130,  161 => 129,  156 => 125,  154 => 124,  153 => 123,  152 => 119,  149 => 118,  147 => 117,  145 => 115,  144 => 113,  143 => 112,  142 => 111,  141 => 110,  140 => 108,  139 => 107,  138 => 106,  137 => 105,  136 => 99,  134 => 97,  132 => 95,  131 => 92,  128 => 89,  126 => 88,  123 => 86,  121 => 85,  119 => 84,  117 => 83,  115 => 80,  114 => 79,  113 => 78,  111 => 76,  109 => 75,  107 => 74,  105 => 73,  103 => 72,  101 => 71,  99 => 70,  97 => 69,  95 => 68,  93 => 67,  91 => 65,  89 => 64,  87 => 63,  85 => 62,  83 => 60,  81 => 59,  76 => 55,  73 => 54,  69 => 52,  67 => 51,  64 => 50,  62 => 49,  57 => 48,  54 => 47,  52 => 46,  50 => 45,  42 => 42,);
    }

    public function getSourceContext()
    {
        return new Source("{#
┌────────────────────────────────────────────────────────────────────────────────────┐
│                                 #global-container                                  │
│   ┌─────┐   ┌──────────────────────────────────────────────────────────────────┐   │
│   │     │   │                         #page-container                          │   │
│   │     │   │   ┌──────────────────────────────────────────────────────────┐   │   │
│   │     │   │   │                      #global-header                      │   │   │
│   │     │   │   └──────────────────────────────────────────────────────────┘   │   │
│   │     │   │                                                                  │   │
│   │     │   │   ┌──────────────────────────────────────────────────────────┐   │   │
│   │     │   │   │                          #main                           │   │   │
│   │  #  │   │   │   ┌──────────────────────────────────────────────────┐   │   │   │
│   │  g  │   │   │   │                #header-container                 │   │   │   │
│   │  l  │   │   │   └──────────────────────────────────────────────────┘   │   │   │
│   │  o  │   │   │                                                          │   │   │
│   │  b  │   │   │   ┌──────────────────────────────────────────────────┐   │   │   │
│   │  a  │   │   │   │                  #main-content                   │   │   │   │
│   │  l  │   │   │   │   ┌─────┐   ┌──────────────────────┐   ┌─────┐   │   │   │   │
│   │  -  │   │   │   │   │     │   │                      │   │     │   │   │   │   │
│   │  s  │   │   │   │   │  #  │   │                      │   │  #  │   │   │   │   │
│   │  i  │   │   │   │   │  s  │   │                      │   │  d  │   │   │   │   │
│   │  d  │   │   │   │   │  i  │   │                      │   │  e  │   │   │   │   │
│   │  e  │   │   │   │   │  d  │   │       #content       │   │  t  │   │   │   │   │
│   │  b  │   │   │   │   │  e  │   │                      │   │  a  │   │   │   │   │
│   │  a  │   │   │   │   │  b  │   │                      │   │  i  │   │   │   │   │
│   │  r  │   │   │   │   │  a  │   │                      │   │  l  │   │   │   │   │
│   │     │   │   │   │   │  r  │   │                      │   │  s  │   │   │   │   │
│   │     │   │   │   │   │     │   │                      │   │     │   │   │   │   │
│   │     │   │   │   │   └─────┘   └──────────────────────┘   └─────┘   │   │   │   │
│   │     │   │   │   │                                                  │   │   │   │
│   │     │   │   │   └──────────────────────────────────────────────────┘   │   │   │
│   │     │   │   │                                                          │   │   │
│   │     │   │   └──────────────────────────────────────────────────────────┘   │   │
│   │     │   │   ┌──────────────────────────────────────────────────────────┐   │   │
│   │     │   │   │                      #global-footer                      │   │   │
│   │     │   │   └──────────────────────────────────────────────────────────┘   │   │
│   └─────┘   └──────────────────────────────────────────────────────────────────┘   │
│                                                                                    │
└────────────────────────────────────────────────────────────────────────────────────┘
#}

{% extends '_layouts/basecp.twig' %}

{# The control panel only supports queue components that implement QueueInterface #}
{% set queue = craft.app.queue %}
{% js %}
    {% if queue is instance of(\"craft\\\\queue\\\\QueueInterface\") %}
        Craft.cp.setJobInfo({{ queue.getJobInfo(100)|json_encode|raw }}, false);
        {% if queue.getHasReservedJobs() %}
            Craft.cp.trackJobProgress(true);
        {% elseif queue.getHasWaitingJobs() %}
            Craft.cp.runQueue();
        {% endif %}
    {% else %}
        Craft.cp.enableQueue = false;
    {% endif %}
{% endjs %}

{% set hasSystemIcon = CraftEdition == CraftPro and craft.rebrand.isIconUploaded %}
{% set fullPageForm = (fullPageForm is defined and fullPageForm) %}

{% set editionName = craft.app.getEditionName() %}
{% set canUpgradeEdition = craft.app.getCanUpgradeEdition() %}
{% set licensedEdition = craft.app.getLicensedEdition() %}
{% set isTrial = licensedEdition is not same as(null) and licensedEdition is not same as(CraftEdition) %}

{% set contentNotice = (contentNotice ?? block('contentNotice') ?? '')|trim %}
{% set sidebar = (sidebar ?? block('sidebar') ?? '')|trim %}
{% set contextMenu = (contextMenu ?? block('contextMenu') ?? '')|trim %}
{% set toolbar = (toolbar ?? block('toolbar') ?? '')|trim %}
{% set actionButton = (block('actionButton') ?? '')|trim %}
{% set additionalButtons = additionalButtons ?? null %}
{% set details = (details ?? block('details') ?? '')|trim %}
{% set footer = (footer ?? block('footer') ?? '')|trim %}
{% set crumbs = crumbs ?? null %}
{% set tabs = (tabs ?? [])|length > 1 ? tabs : null %}

{% set mainContentClasses = [
    sidebar ? 'has-sidebar',
    details ? 'has-details',
]|filter %}

{% set bodyClass = (bodyClass ?? [])|explodeClass %}
{% set showHeader = showHeader ?? true %}
{% if not showHeader %}
    {% set bodyClass = bodyClass|push('no-header') -%}
{% endif %}
{% if craft.app.hasModule('debug') %}
    {% set bodyClass = bodyClass|push('has-debug-toolbar') %}
{% endif %}

{% set mainAttributes = {
    id: 'main',
    role: 'main',
}|merge(mainAttributes ?? []) %}

{% set formActions = craft.cp.prepFormActions(formActions ?? null) %}

{% set mainFormAttributes = {
    id: 'main-form',
    method: 'post',
    'accept-charset': 'UTF-8',
    novalidate: true,
    data: {
        saveshortcut: saveShortcut ?? true,
        'saveshortcut-redirect': (saveShortcutRedirect ?? false) ? saveShortcutRedirect|hash : false,
        'saveshortcut-scroll': retainScrollOnSaveShortcut ?? false,
        actions: formActions ?? false,
        'confirm-unload': true,
        delta: view.getIsDeltaRegistrationActive(),
        'delta-names': view.getDeltaNames(),
        'initial-delta-values': view.getInitialDeltaValues(),
        'modified-delta-names': craft.app.request.getBodyParam('modifiedDeltaNames') ?? [],
    },
}|merge(mainFormAttributes ?? [], recursive=true) %}

{% set userPhoto %}
    <div class=\"header-photo\">
        {{ tag('img', {
            width: 30,
            height: 30,
            sizes: '30px',
            srcset: \"#{currentUser.getThumbUrl(30)} 30w, #{currentUser.getThumbUrl(60)} 60w\",
            alt: currentUser.getThumbAlt(),
        }) }}
    </div>
{% endset %}

{% js at head %}
    // Remove the hash so the browser doesn't scroll to it
    window.LOCATION_HASH = document.location.hash ? decodeURIComponent(document.location.hash.substr(1)) : null;
    history.replaceState(undefined, undefined, window.location.href.match(/^[^#]*/)[0]);
{% endjs %}

{% block body %}
    {{ tag ('a', {
        id: 'global-skip-link',
        text: 'Skip to content'|t('app'),
        href: '#main',
        class: 'skip-link btn',
    }) }}

    <div id=\"global-container\">
        {% include '_layouts/components/global-sidebar' %}

        <div id=\"page-container\">
            {% include '_layouts/components/alerts' %}

            <div id=\"global-header\" role=\"region\" aria-label=\"{{ 'My Account'|t('app') }}\">
                <div class=\"flex\">
                    {% include '_layouts/components/crumbs' %}
                    <div class=\"flex-grow\"></div>
                    <button type=\"button\" id=\"announcements-btn\" class=\"btn hidden\" title=\"{{ 'What’s New'|t('app') }}\">
                        <span class=\"visually-hidden\">{{ 'What’s New'|t('app') }}</span>
                        {{ svg('@app/icons/gift.svg') }}
                    </button>

                    {# New account dropdown #}
                    <div class=\"account-toggle-wrapper\">
                        <button
                            id=\"user-info\"
                            aria-controls=\"account-menu\"
                            class=\"btn menu-toggle\"
                            aria-label=\"{{ 'My Account'|t('app') }}\"
                            title=\"{{ 'My Account'|t('app') }}\"
                            data-disclosure-trigger>
                            {{ userPhoto }}
                        </button>
                        <div id=\"account-menu\" class=\"menu menu--disclosure\" data-align=\"right\" data-align-to=\".header-photo\">
                            <ul>
                                <li>
                                    <a href=\"{{ url('myaccount') }}\" class=\"flex flex-nowrap\">
                                        {% if currentUser.photoId %}
                                            {{ userPhoto }}
                                        {% endif %}
                                        <div class=\"flex-grow\">
                                            <div>{{ currentUser.username }}</div>
                                            {% if not craft.app.config.general.useEmailAsUsername %}
                                                <div class=\"smalltext\">{{ currentUser.email }}</div>
                                            {% endif %}
                                        </div>
                                    </a>
                                </li>
                            </ul>
                            <hr>
                            <ul>
                                <li><a href=\"{{ url('logout') }}\">{{ \"Sign out\"|t('app') }}</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div id=\"main-container\">
                <main {{ attr(mainAttributes) }}>

                    {% if fullPageForm -%}
                        <form {% block mainFormAttributes %}{{ attr(mainFormAttributes) }}{% endblock %}>
                            {{- csrfInput() }}
                    {%- endif %}

                    {% if showHeader %}
                        <div id=\"header-container\">
                            <header id=\"header\">
                                {% block header %}
                                    <div id=\"page-title\" class=\"flex{% if toolbar %} has-toolbar{% endif %}\">
                                        {% block pageTitle %}
                                            {% if title is defined and title|length %}
                                                <h1 class=\"screen-title\" title=\"{{ title }}\">{{ title }}</h1>
                                            {% endif %}
                                        {% endblock %}
                                        {{ contextMenu|raw }}
                                    </div>
                                    {% if toolbar %}
                                        <div id=\"toolbar\" class=\"flex\">
                                            {{ toolbar|raw }}
                                        </div>
                                    {% endif %}
                                    {% if actionButton or additionalButtons %}
                                        <div id=\"action-buttons\" class=\"flex\">
                                            {{ additionalButtons|raw }}
                                            {{ actionButton|raw }}
                                        </div>
                                    {% endif %}
                                {% endblock %}
                            </header><!-- #header -->
                        </div>
                    {% endif %}

                    <div id=\"main-content\" class=\"{{ mainContentClasses|join(' ') }}\">
                        {# sidebar #}
                        {% if sidebar %}
                            <div id=\"sidebar-toggle-container\">
                                <button type=\"button\" id=\"sidebar-toggle\" class=\"btn menubtn\" aria-controls=\"sidebar-container\" aria-expanded=\"false\">
                                    {{ 'Show sidebar'|t('app') }}
                                </button>
                            </div>
                            <div id=\"sidebar-container\">
                                <div id=\"sidebar\" class=\"sidebar\">
                                    {{ sidebar|raw }}
                                </div>
                            </div>
                        {% endif %}

                        {# content-container #}
                        <div id=\"content-container\">
                            {% if sidebar %}
                                <h2 id=\"content-heading\"></h2>
                            {% endif %}
                            {% block main %}
                                <div id=\"content\" class=\"content-pane\">
                                    {% if contentNotice or tabs %}
                                        <header id=\"content-header\" class=\"pane-header\">
                                            {{ contentNotice ? tag('div', {
                                                id: 'content-notice',
                                                html: contentNotice,
                                                role: 'status',
                                            }) }}
                                            {% if tabs %}
                                                {% include \"_includes/tabs\" with {
                                                    containerAttributes: {
                                                        id: 'tabs',
                                                    },
                                                } %}
                                            {% endif %}
                                        </header>
                                    {% endif %}

                                    {% block content %}
                                        {{ content is defined ? content|raw }}
                                    {% endblock %}

                                    {# footer #}
                                    {% if footer %}
                                        <div id=\"footer\" class=\"flex flex-justify\">
                                            {{ footer|raw }}
                                        </div>
                                    {% endif %}
                                </div>
                            {% endblock %}
                        </div><!-- #content-container -->

                        {% if details is not empty %}
                            <div id=\"details-container\">
                                <div id=\"details\">
                                    <div class=\"details\">
                                        {{ details|raw }}
                                    </div>
                                </div>
                            </div>
                        {% endif %}
                    </div><!-- #main-content -->

                    {% if fullPageForm -%}
                        </form><!-- #main-form -->
                    {%- endif %}
                </main><!-- #main -->
            </div><!-- #main-container -->

            <footer id=\"global-footer\">
                {% set fullEditionName = '{edition} edition'|t('app', {edition: editionName}) ~ (isTrial ? ' ' ~ '(trial)'|t('app')) %}
                <div id=\"edition-logo\" title=\"{{ fullEditionName }}\">
                    <div class=\"edition-name\" aria-hidden=\"true\">{{ editionName }}</div>
                    {{ tag('span', {
                        class: 'visually-hidden',
                        text: fullEditionName,
                    }) }}
                    {% if isTrial %}
                        <div class=\"edition-trial\">{{ \"Trial\"|t('app') }}</div>
                    {% endif %}
                </div>
                <div id=\"app-info\">
                    <span>Craft CMS {{ craft.app.version }}</span>
                    {% if canUpgradeEdition %}
                        {% set linkText = isTrial ? 'Buy Craft Pro'|t('app') : 'Upgrade to Craft Pro'|t('app') %}
                        <span>
                            <a class=\"go\" href=\"{{ url('plugin-store/upgrade-craft') }}\" aria-label=\"{{ linkText }}\">{{ linkText }}</a>
                        </span>
                    {% endif %}
                </div>
            </footer>

        </div><!-- #page-container -->
    </div><!-- #global-container -->

    {% include '_layouts/components/notifications' %}
{% endblock %}


{% block actionButton %}
    {% if fullPageForm %}
        <div class=\"btngroup\">
            {% block submitButton %}
                <button type=\"submit\" class=\"btn submit\">{{ submitButtonLabel ?? 'Save'|t('app') }}</button>
            {% endblock %}
            {% if formActions ?? false %}
                <button type=\"button\" class=\"btn submit menubtn\" aria-label=\"{{ 'More actions'|t('app') }}\"></button>
                {% include '_layouts/components/form-action-menu' %}
            {% endif %}
        </div>
    {% endif %}
{% endblock %}


{% if currentUser.can('performUpdates') and not craft.app.updates.getIsUpdateInfoCached() %}
    {% js %}
        Craft.cp.checkForUpdates();
    {% endjs %}
{% endif %}
", "_layouts/cp", "/var/www/html/vendor/craftcms/cms/src/templates/_layouts/cp.twig");
    }
}

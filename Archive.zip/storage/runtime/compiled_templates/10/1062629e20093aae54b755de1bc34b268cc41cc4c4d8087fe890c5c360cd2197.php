<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms/checkboxGroup */
class __TwigTemplate_5fed7d31a904de55d75ea6f3df28fb7fe9d2e38135adc117112a6ec64633887e extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/checkboxGroup");
        // line 1
        $context["options"] = (($context["options"]) ?? ([]));
        // line 2
        $context["values"] = (($context["values"]) ?? ([]));
        // line 3
        $context["optionName"] = (((($context["name"]) ?? (false))) ? (((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 3, $this->source); })()) . "[]")) : (null));
        // line 4
        echo "
";
        // line 5
        $context["fieldsetAttributes"] = ["class" => [0 => "checkbox-group"]];
        // line 8
        echo "
";
        // line 9
        if (        $this->hasBlock("attr", $context, $blocks)) {
            // line 10
            $context["fieldsetAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["fieldsetAttributes"]) || array_key_exists("fieldsetAttributes", $context) ? $context["fieldsetAttributes"] : (function () { throw new RuntimeError('Variable "fieldsetAttributes" does not exist.', 10, $this->source); })()), $this->extensions['craft\web\twig\Extension']->parseAttrFilter((("<div " .             $this->renderBlock("attr", $context, $blocks)) . ">")), true);
        }
        // line 12
        echo "
";
        // line 13
        ob_start();
        // line 14
        echo "    ";
        if ((($context["name"]) ?? (false))) {
            // line 15
            echo "        ";
            echo craft\helpers\Html::hiddenInput((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 15, $this->source); })()), "");
            echo "
    ";
        }
        // line 18
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new RuntimeError('Variable "options" does not exist.', 18, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["key"] => $context["option"]) {
            // line 19
            if ( !twig_test_iterable($context["option"])) {
                // line 20
                $context["option"] = ["label" => $context["option"], "value" => $context["key"]];
            }
            // line 22
            echo "        <div class=\"checkboxfield\">
            ";
            // line 23
            $this->loadTemplate("_includes/forms/checkbox", "_includes/forms/checkboxGroup", 23)->display(twig_to_array($this->extensions['craft\web\twig\Extension']->mergeFilter(["describedBy" => ((            // line 24
$context["describedBy"]) ?? (false)), "name" =>             // line 25
(isset($context["optionName"]) || array_key_exists("optionName", $context) ? $context["optionName"] : (function () { throw new RuntimeError('Variable "optionName" does not exist.', 25, $this->source); })()), "checked" => (craft\helpers\Template::attribute($this->env, $this->source,             // line 26
$context["option"], "value", [], "any", true, true) && twig_in_filter(craft\helpers\Template::attribute($this->env, $this->source, $context["option"], "value", []), (isset($context["values"]) || array_key_exists("values", $context) ? $context["values"] : (function () { throw new RuntimeError('Variable "values" does not exist.', 26, $this->source); })()))), "autofocus" => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 27
$context["loop"], "first", []) && (($context["autofocus"]) ?? (false))) &&  !craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 27, $this->source); })()), "app", []), "request", []), "isMobileBrowser", [0 => true], "method"))],             // line 28
$context["option"])));
            // line 29
            echo "        </div>";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['option'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        echo craft\helpers\Html::tag("div", ob_get_clean(),         // line 13
(isset($context["fieldsetAttributes"]) || array_key_exists("fieldsetAttributes", $context) ? $context["fieldsetAttributes"] : (function () { throw new RuntimeError('Variable "fieldsetAttributes" does not exist.', 13, $this->source); })()));
        craft\helpers\Template::endProfile("template", "_includes/forms/checkboxGroup");
    }

    public function getTemplateName()
    {
        return "_includes/forms/checkboxGroup";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 13,  103 => 29,  101 => 28,  100 => 27,  99 => 26,  98 => 25,  97 => 24,  96 => 23,  93 => 22,  90 => 20,  88 => 19,  71 => 18,  65 => 15,  62 => 14,  60 => 13,  57 => 12,  54 => 10,  52 => 9,  49 => 8,  47 => 5,  44 => 4,  42 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{%- set options = options ?? [] %}
{%- set values = values ?? [] %}
{%- set optionName = (name ?? false) ? \"#{name}[]\" : null %}

{% set fieldsetAttributes = {
    class: ['checkbox-group'],
} %}

{% if block('attr') is defined %}
    {%- set fieldsetAttributes = fieldsetAttributes|merge(('<div ' ~ block('attr') ~ '>')|parseAttr, recursive=true) %}
{% endif %}

{% tag 'div' with fieldsetAttributes %}
    {% if name ?? false %}
        {{ hiddenInput(name, '') }}
    {% endif -%}

    {%- for key, option in options %}
        {%- if option is not iterable %}
            {%- set option = {label: option, value: key} %}
        {%- endif %}
        <div class=\"checkboxfield\">
            {% include \"_includes/forms/checkbox\" with {
                describedBy: describedBy ?? false,
                name: optionName,
                checked: (option.value is defined and option.value in values),
                autofocus: loop.first and (autofocus ?? false) and not craft.app.request.isMobileBrowser(true)
            }|merge(option) only %}
        </div>
    {%- endfor %}
{% endtag %}
", "_includes/forms/checkboxGroup", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/checkboxGroup.twig");
    }
}

<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* globals/nav */
class __TwigTemplate_609cae2087bb0daec9877fdf82cb93152e60fa8e61d4fb53a22e2d50b06f974e extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "globals/nav");
        craft\helpers\Template::preloadSingles(['header', 'siteUrl', 'logod', 'logol', 'link', 'craft', 'destination']);
        // line 1
        echo "<header class=\"header header-sticky default\">
      <nav class=\"navbar navbar-static-top navbar-expand-xl\">
       ";
        // line 3
        $context["logol"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["header"]) || array_key_exists("header", $context) ? $context["header"] : (craft\helpers\Template::fallbackExists("header") ? craft\helpers\Template::fallback("header") : (function () { throw new RuntimeError('Variable "header" does not exist.', 3, $this->source); })())), "logoLight", []), "one", [], "method");
        // line 4
        echo "       ";
        $context["logod"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["header"]) || array_key_exists("header", $context) ? $context["header"] : (craft\helpers\Template::fallbackExists("header") ? craft\helpers\Template::fallback("header") : (function () { throw new RuntimeError('Variable "header" does not exist.', 4, $this->source); })())), "logoDark", []), "one", [], "method");
        // line 5
        echo "        <div class=\"container-fluid main-header position-relative\">
          <button type=\"button\" class=\"navbar-toggler\" data-bs-toggle=\"collapse\" data-bs-target=\".navbar-collapse\"><i class=\"fas fa-align-left\"></i></button>
          <a class=\"navbar-brand\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 7, $this->source); })())), "html", null, true);
        echo "\">
            <img class=\"logo img-fluid\" src=\"";
        // line 8
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["logod"]) || array_key_exists("logod", $context) ? $context["logod"] : (craft\helpers\Template::fallbackExists("logod") ? craft\helpers\Template::fallback("logod") : (function () { throw new RuntimeError('Variable "logod" does not exist.', 8, $this->source); })())), "url", []), "html", null, true);
        echo "\" alt=\"logo\">
            <img class=\"sticky-logo img-fluid\" src=\"";
        // line 9
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["logol"]) || array_key_exists("logol", $context) ? $context["logol"] : (craft\helpers\Template::fallbackExists("logol") ? craft\helpers\Template::fallback("logol") : (function () { throw new RuntimeError('Variable "logol" does not exist.', 9, $this->source); })())), "url", []), "html", null, true);
        echo "\" alt=\"logo\">
          </a>
          <div class=\"navbar-collapse collapse\">
            <ul class=\"nav navbar-nav\">
              ";
        // line 13
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["header"]) || array_key_exists("header", $context) ? $context["header"] : (craft\helpers\Template::fallbackExists("header") ? craft\helpers\Template::fallback("header") : (function () { throw new RuntimeError('Variable "header" does not exist.', 13, $this->source); })())), "navLinks", []), "all", [], "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["link"]) {
            // line 14
            echo "                            ";
            $context["destination"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["link"], "linkDestination", []), "one", [], "method");
            // line 15
            echo "                            ";
            $context["activeLink"] = (twig_first($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (craft\helpers\Template::fallbackExists("craft") ? craft\helpers\Template::fallback("craft") : (function () { throw new RuntimeError('Variable "craft" does not exist.', 15, $this->source); })())), "app", []), "request", []), "segments", [])) == craft\helpers\Template::attribute($this->env, $this->source, (isset($context["destination"]) || array_key_exists("destination", $context) ? $context["destination"] : (craft\helpers\Template::fallbackExists("destination") ? craft\helpers\Template::fallback("destination") : (function () { throw new RuntimeError('Variable "destination" does not exist.', 15, $this->source); })())), "uri", []));
            // line 16
            echo "\t\t\t\t\t\t\t<li class=\"nav-item\"> <a class=\"nav-link\" href=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["destination"]) || array_key_exists("destination", $context) ? $context["destination"] : (craft\helpers\Template::fallbackExists("destination") ? craft\helpers\Template::fallback("destination") : (function () { throw new RuntimeError('Variable "destination" does not exist.', 16, $this->source); })())), "url", []), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["link"], "linkText", []), "html", null, true);
            echo "</a></li>
\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['link'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        echo "            </ul>
          </div>
          <div class=\"add-listing\">
            <div class=\"need-help\">
              <div class=\"icon\">
                <img src=\"";
        // line 23
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 23, $this->source); })())), "html", null, true);
        echo "images/svg/phone-01.svg\" alt=\"#\">
              </div>
              <div class=\"help-info\">
                <p>";
        // line 26
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["header"]) || array_key_exists("header", $context) ? $context["header"] : (craft\helpers\Template::fallbackExists("header") ? craft\helpers\Template::fallback("header") : (function () { throw new RuntimeError('Variable "header" does not exist.', 26, $this->source); })())), "navMore", []), "html", null, true);
        echo "</p>
                <span>";
        // line 27
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["header"]) || array_key_exists("header", $context) ? $context["header"] : (craft\helpers\Template::fallbackExists("header") ? craft\helpers\Template::fallback("header") : (function () { throw new RuntimeError('Variable "header" does not exist.', 27, $this->source); })())), "navPhone", []), "html", null, true);
        echo "</span>
              </div>
            </div>
              <div class=\"side-menu\">
                <a href=\"#\" data-bs-toggle=\"offcanvas\" data-bs-target=\"#offcanvasRight\" aria-controls=\"offcanvasRight\">
                  <img src=\"";
        // line 32
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 32, $this->source); })())), "html", null, true);
        echo "images/svg/menu.svg\" alt=\"#\">
                  <img class=\"menu-dark\" src=\"";
        // line 33
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 33, $this->source); })())), "html", null, true);
        echo "images/svg/menu-dark.svg\" alt=\"#\">
                </a>
              </div>
            </div>
          </div>
        </nav>
      </header>
      <!--=================================
      Header -->
      <!--=================================
      Right menu -->
      <!--=================================
      Right menu -->
      <div class=\"offcanvas offcanvas-end offcanvas-sidebar-menu\" tabindex=\"-1\" id=\"offcanvasRight\">
        <div class=\"offcanvas-header text-end justify-content-end p-4\">
          <button type=\"button\" class=\"btn-close text-reset\" data-bs-dismiss=\"offcanvas\" aria-label=\"Close\"><i class=\"fa-solid fa-xmark\"></i></button>
        </div>
        <div class=\"offcanvas-body p-4 p-sm-5 d-flex align-content-between flex-wrap justify-content-center\">
          <div class=\"sidebar-menu\">
            <div class=\"sidebar-logo\">
              <a href=\"";
        // line 53
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 53, $this->source); })())), "html", null, true);
        echo "\">
                <img class=\"logo img-fluid\" src=\"";
        // line 54
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["logod"]) || array_key_exists("logod", $context) ? $context["logod"] : (craft\helpers\Template::fallbackExists("logod") ? craft\helpers\Template::fallback("logod") : (function () { throw new RuntimeError('Variable "logod" does not exist.', 54, $this->source); })())), "url", []), "html", null, true);
        echo "\" alt=\"logo\">
              </a>
            </div>
            <div class=\"section-title mt-5\">
              <h3 class=\"title text-white\">About us</h3>
              <p class=\"text-white\">";
        // line 59
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["header"]) || array_key_exists("header", $context) ? $context["header"] : (craft\helpers\Template::fallbackExists("header") ? craft\helpers\Template::fallback("header") : (function () { throw new RuntimeError('Variable "header" does not exist.', 59, $this->source); })())), "sidebarAbout", []), "html", null, true);
        echo "</p>
            </div>
            <div class=\"mt-5\">
              <h3 class=\"mb-3 text-white\">Contact Info</h3>
              <p class=\"text-white\">";
        // line 63
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["header"]) || array_key_exists("header", $context) ? $context["header"] : (craft\helpers\Template::fallbackExists("header") ? craft\helpers\Template::fallback("header") : (function () { throw new RuntimeError('Variable "header" does not exist.', 63, $this->source); })())), "contactAddress", []), "html", null, true);
        echo "</p>
              <h5 class=\"text-white\">";
        // line 64
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["header"]) || array_key_exists("header", $context) ? $context["header"] : (craft\helpers\Template::fallbackExists("header") ? craft\helpers\Template::fallback("header") : (function () { throw new RuntimeError('Variable "header" does not exist.', 64, $this->source); })())), "contactPhone", []), "html", null, true);
        echo "</h5>
              <h5 class=\"text-white\">";
        // line 65
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["header"]) || array_key_exists("header", $context) ? $context["header"] : (craft\helpers\Template::fallbackExists("header") ? craft\helpers\Template::fallback("header") : (function () { throw new RuntimeError('Variable "header" does not exist.', 65, $this->source); })())), "contactEmail", []), "html", null, true);
        echo "</h5>
            </div>
            <div class=\"social-icon mt-5\">
              <ul>
                <li><a href=\"#\"><i class=\"fa-brands fa-facebook-f\"></i></a></li>
                <li><a href=\"#\"><i class=\"fab fa-twitter\"></i></a></li>
                <li><a href=\"#\"><i class=\"fab fa-linkedin-in\"></i></a></li>
                <li><a href=\"#\"><i class=\"fab fa-instagram\"></i></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <!--=================================
      Right menu -->";
        craft\helpers\Template::endProfile("template", "globals/nav");
    }

    public function getTemplateName()
    {
        return "globals/nav";
    }

    public function getDebugInfo()
    {
        return array (  167 => 65,  163 => 64,  159 => 63,  152 => 59,  144 => 54,  140 => 53,  117 => 33,  113 => 32,  105 => 27,  101 => 26,  95 => 23,  88 => 18,  77 => 16,  74 => 15,  71 => 14,  67 => 13,  60 => 9,  56 => 8,  52 => 7,  48 => 5,  45 => 4,  43 => 3,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<header class=\"header header-sticky default\">
      <nav class=\"navbar navbar-static-top navbar-expand-xl\">
       {% set logol = header.logoLight.one() %}
       {% set logod = header.logoDark.one() %}
        <div class=\"container-fluid main-header position-relative\">
          <button type=\"button\" class=\"navbar-toggler\" data-bs-toggle=\"collapse\" data-bs-target=\".navbar-collapse\"><i class=\"fas fa-align-left\"></i></button>
          <a class=\"navbar-brand\" href=\"{{ siteUrl }}\">
            <img class=\"logo img-fluid\" src=\"{{ logod.url }}\" alt=\"logo\">
            <img class=\"sticky-logo img-fluid\" src=\"{{ logol.url }}\" alt=\"logo\">
          </a>
          <div class=\"navbar-collapse collapse\">
            <ul class=\"nav navbar-nav\">
              {% for link in header.navLinks.all() %}
                            {% set destination = link.linkDestination.one() %}
                            {% set activeLink = craft.app.request.segments|first == destination.uri %}
\t\t\t\t\t\t\t<li class=\"nav-item\"> <a class=\"nav-link\" href=\"{{ destination.url }}\">{{ link.linkText }}</a></li>
\t\t\t\t\t\t\t{% endfor %}
            </ul>
          </div>
          <div class=\"add-listing\">
            <div class=\"need-help\">
              <div class=\"icon\">
                <img src=\"{{ siteUrl }}images/svg/phone-01.svg\" alt=\"#\">
              </div>
              <div class=\"help-info\">
                <p>{{ header.navMore }}</p>
                <span>{{ header.navPhone }}</span>
              </div>
            </div>
              <div class=\"side-menu\">
                <a href=\"#\" data-bs-toggle=\"offcanvas\" data-bs-target=\"#offcanvasRight\" aria-controls=\"offcanvasRight\">
                  <img src=\"{{ siteUrl }}images/svg/menu.svg\" alt=\"#\">
                  <img class=\"menu-dark\" src=\"{{ siteUrl }}images/svg/menu-dark.svg\" alt=\"#\">
                </a>
              </div>
            </div>
          </div>
        </nav>
      </header>
      <!--=================================
      Header -->
      <!--=================================
      Right menu -->
      <!--=================================
      Right menu -->
      <div class=\"offcanvas offcanvas-end offcanvas-sidebar-menu\" tabindex=\"-1\" id=\"offcanvasRight\">
        <div class=\"offcanvas-header text-end justify-content-end p-4\">
          <button type=\"button\" class=\"btn-close text-reset\" data-bs-dismiss=\"offcanvas\" aria-label=\"Close\"><i class=\"fa-solid fa-xmark\"></i></button>
        </div>
        <div class=\"offcanvas-body p-4 p-sm-5 d-flex align-content-between flex-wrap justify-content-center\">
          <div class=\"sidebar-menu\">
            <div class=\"sidebar-logo\">
              <a href=\"{{ siteUrl }}\">
                <img class=\"logo img-fluid\" src=\"{{ logod.url }}\" alt=\"logo\">
              </a>
            </div>
            <div class=\"section-title mt-5\">
              <h3 class=\"title text-white\">About us</h3>
              <p class=\"text-white\">{{ header.sidebarAbout}}</p>
            </div>
            <div class=\"mt-5\">
              <h3 class=\"mb-3 text-white\">Contact Info</h3>
              <p class=\"text-white\">{{ header.contactAddress }}</p>
              <h5 class=\"text-white\">{{ header.contactPhone }}</h5>
              <h5 class=\"text-white\">{{ header.contactEmail }}</h5>
            </div>
            <div class=\"social-icon mt-5\">
              <ul>
                <li><a href=\"#\"><i class=\"fa-brands fa-facebook-f\"></i></a></li>
                <li><a href=\"#\"><i class=\"fab fa-twitter\"></i></a></li>
                <li><a href=\"#\"><i class=\"fab fa-linkedin-in\"></i></a></li>
                <li><a href=\"#\"><i class=\"fab fa-instagram\"></i></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <!--=================================
      Right menu -->", "globals/nav", "/var/www/html/templates/globals/nav.twig");
    }
}

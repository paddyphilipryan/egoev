<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _elements/list.twig */
class __TwigTemplate_ab812bbcc8c6b864b1bef03dc6d5b244e7adcc483361f29b89df19520472ea4a extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_elements/list.twig");
        // line 1
        $context["elements"] = (($context["elements"]) ?? ([]));
        // line 2
        $context["disabled"] = (($context["disabled"]) ?? (null));
        // line 3
        $context["viewMode"] = (($context["viewMode"]) ?? (null));
        // line 4
        echo "
<div class=\"elements\">
    ";
        // line 6
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["elements"]) || array_key_exists("elements", $context) ? $context["elements"] : (function () { throw new RuntimeError('Variable "elements" does not exist.', 6, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["element"]) {
            // line 7
            echo "        ";
            $context["element"] = twig_include($this->env, $context, "_elements/element", ["context" => "field", "size" => (((            // line 9
(isset($context["viewMode"]) || array_key_exists("viewMode", $context) ? $context["viewMode"] : (function () { throw new RuntimeError('Variable "viewMode" does not exist.', 9, $this->source); })()) == "large")) ? ("large") : ("small"))]);
            // line 11
            echo "        ";
            if ((isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 11, $this->source); })())) {
                // line 12
                echo "            ";
                $context["element"] = $this->extensions['craft\web\twig\Extension']->removeClassFilter($context["element"], "removable");
                // line 13
                echo "        ";
            }
            // line 14
            echo "        ";
            echo $context["element"];
            echo "
    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['element'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 16
        echo "</div>";
        craft\helpers\Template::endProfile("template", "_elements/list.twig");
    }

    public function getTemplateName()
    {
        return "_elements/list.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  95 => 16,  78 => 14,  75 => 13,  72 => 12,  69 => 11,  67 => 9,  65 => 7,  48 => 6,  44 => 4,  42 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% set elements = elements ?? [] %}
{% set disabled = disabled ?? null %}
{% set viewMode = viewMode ?? null %}

<div class=\"elements\">
    {% for element in elements %}
        {% set element = include('_elements/element', {
            context: 'field',
            size: (viewMode == 'large' ? 'large' : 'small')
        }) %}
        {% if disabled %}
            {% set element = element|removeClass('removable') %}
        {% endif %}
        {{ element|raw }}
    {% endfor %}
</div>", "_elements/list.twig", "/var/www/html/vendor/craftcms/cms/src/templates/_elements/list.twig");
    }
}

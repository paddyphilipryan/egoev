<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* index */
class __TwigTemplate_0749adf419f828db958bbad1bbea4b979f49db66098d1c385d087ffd1b3f6a73 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "index");
        craft\helpers\Template::preloadSingles(['siteUrl']);
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
  <head>
    <meta charset=\"utf-8\">
    <meta name=\"keywords\" content=\"EGO EV CHARGERS\">
    <meta name=\"description\" content=\"EGO EV CHARGERS\">
    <meta name=\"author\" content=\"busylittlepixels.com\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
    <title>EGO EV CHARGERS</title>

    <!-- Favicon -->
    <link rel=\"shortcut icon\" href=\"";
        // line 12
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 12, $this->source); })())), "html", null, true);
        echo "images/favicon.ico\">

    <!-- Google Font -->
    <link rel=\"preconnect\" href=\"https://fonts.googleapis.com\">
    <link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin>
    <link href=\"https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap\" rel=\"stylesheet\">

    <!-- CSS Global Compulsory (Do not remove)-->
    <link rel=\"stylesheet\" href=\"";
        // line 20
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 20, $this->source); })())), "html", null, true);
        echo "css/fontawesome/all.min.css\">
    <link rel=\"stylesheet\" href=\"";
        // line 21
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 21, $this->source); })())), "html", null, true);
        echo "css/bootstrap/bootstrap.min.css\">

    <!-- Page CSS Implementing Plugins (Remove the plugin CSS here if site does not use that feature)-->
    <link rel=\"stylesheet\" href=\"";
        // line 24
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 24, $this->source); })())), "html", null, true);
        echo "css/owl-carousel/owl.carousel.min.css\">
    <link rel=\"stylesheet\" href=\"";
        // line 25
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 25, $this->source); })())), "html", null, true);
        echo "css/animate/animate.min.css\">
    <link rel=\"stylesheet\" href=\"";
        // line 26
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 26, $this->source); })())), "html", null, true);
        echo "css/swiper/swiper.min.css\">
    <link rel=\"stylesheet\" href=\"";
        // line 27
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 27, $this->source); })())), "html", null, true);
        echo "css/magnific-popup/magnific-popup.css\">

    <!-- Template Style -->
    <link rel=\"stylesheet\" href=\"";
        // line 30
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 30, $this->source); })())), "html", null, true);
        echo "css/style.css\">
  ";
        // line 31
        $this->env->getFunction('head')->getCallable()();
        echo "</head>
  <body>";
        // line 32
        $this->env->getFunction('beginBody')->getCallable()();
        echo "
";
        // line 33
        $this->loadTemplate("globals/nav", "index", 33)->display($context);
        echo "\t

<!--==== Main content START -->
 

     ";
        // line 38
        $this->displayBlock('content', $context, $blocks);
        // line 40
        echo "      



<!--==== Main content END -->
";
        // line 45
        $this->loadTemplate("globals/footer", "index", 45)->display($context);
        echo " 
    <!--=================================
      Javascript -->
      <!-- JS Global Compulsory (Do not remove)-->
      <script src=\"";
        // line 49
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 49, $this->source); })())), "html", null, true);
        echo "js/jquery-3.6.1.min.js\"></script>
      <script src=\"";
        // line 50
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 50, $this->source); })())), "html", null, true);
        echo "js/jquery.appear.js\"></script>
      <script src=\"";
        // line 51
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 51, $this->source); })())), "html", null, true);
        echo "js/popper/popper.min.js\"></script>
      <script src=\"";
        // line 52
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 52, $this->source); })())), "html", null, true);
        echo "js/bootstrap/bootstrap.min.js\"></script>

      <!-- Page JS Implementing Plugins (Remove the plugin script here if site does not use that feature)-->
      <script src=\"";
        // line 55
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 55, $this->source); })())), "html", null, true);
        echo "js/owl-carousel/owl.carousel.min.js\"></script>
      <script src=\"";
        // line 56
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 56, $this->source); })())), "html", null, true);
        echo "js/swiper/swiper.min.js\"></script>
      <script src=\"";
        // line 57
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 57, $this->source); })())), "html", null, true);
        echo "js/swiperanimation/SwiperAnimation.min.js\"></script>
      <script src=\"";
        // line 58
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 58, $this->source); })())), "html", null, true);
        echo "js/magnific-popup/jquery.magnific-popup.min.js\"></script>
      <script src=\"";
        // line 59
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 59, $this->source); })())), "html", null, true);
        echo "js/counter/jquery.countTo.js\"></script>

      <!-- Template Scripts (Do not remove)-->
      <script src=\"";
        // line 62
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 62, $this->source); })())), "html", null, true);
        echo "js/custom.js\"></script>
      
    ";
        // line 64
        $this->env->getFunction('endBody')->getCallable()();
        echo "</body>
  </html>";
        craft\helpers\Template::endProfile("template", "index");
    }

    // line 38
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 39
        echo "    ";
        // line 40
        echo "    ";
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "index";
    }

    public function getDebugInfo()
    {
        return array (  187 => 40,  185 => 39,  180 => 38,  173 => 64,  168 => 62,  162 => 59,  158 => 58,  154 => 57,  150 => 56,  146 => 55,  140 => 52,  136 => 51,  132 => 50,  128 => 49,  121 => 45,  114 => 40,  112 => 38,  104 => 33,  100 => 32,  96 => 31,  92 => 30,  86 => 27,  82 => 26,  78 => 25,  74 => 24,  68 => 21,  64 => 20,  53 => 12,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html lang=\"en\">
  <head>
    <meta charset=\"utf-8\">
    <meta name=\"keywords\" content=\"EGO EV CHARGERS\">
    <meta name=\"description\" content=\"EGO EV CHARGERS\">
    <meta name=\"author\" content=\"busylittlepixels.com\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
    <title>EGO EV CHARGERS</title>

    <!-- Favicon -->
    <link rel=\"shortcut icon\" href=\"{{ siteUrl }}images/favicon.ico\">

    <!-- Google Font -->
    <link rel=\"preconnect\" href=\"https://fonts.googleapis.com\">
    <link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin>
    <link href=\"https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap\" rel=\"stylesheet\">

    <!-- CSS Global Compulsory (Do not remove)-->
    <link rel=\"stylesheet\" href=\"{{ siteUrl }}css/fontawesome/all.min.css\">
    <link rel=\"stylesheet\" href=\"{{ siteUrl }}css/bootstrap/bootstrap.min.css\">

    <!-- Page CSS Implementing Plugins (Remove the plugin CSS here if site does not use that feature)-->
    <link rel=\"stylesheet\" href=\"{{ siteUrl }}css/owl-carousel/owl.carousel.min.css\">
    <link rel=\"stylesheet\" href=\"{{ siteUrl }}css/animate/animate.min.css\">
    <link rel=\"stylesheet\" href=\"{{ siteUrl }}css/swiper/swiper.min.css\">
    <link rel=\"stylesheet\" href=\"{{ siteUrl }}css/magnific-popup/magnific-popup.css\">

    <!-- Template Style -->
    <link rel=\"stylesheet\" href=\"{{ siteUrl }}css/style.css\">
  </head>
  <body>
{% include \"globals/nav\" %}\t

<!--==== Main content START -->
 

     {% block content %}
    {# Template goes here #}
    {% endblock %}      



<!--==== Main content END -->
{% include \"globals/footer\" %} 
    <!--=================================
      Javascript -->
      <!-- JS Global Compulsory (Do not remove)-->
      <script src=\"{{ siteUrl }}js/jquery-3.6.1.min.js\"></script>
      <script src=\"{{ siteUrl }}js/jquery.appear.js\"></script>
      <script src=\"{{ siteUrl }}js/popper/popper.min.js\"></script>
      <script src=\"{{ siteUrl }}js/bootstrap/bootstrap.min.js\"></script>

      <!-- Page JS Implementing Plugins (Remove the plugin script here if site does not use that feature)-->
      <script src=\"{{ siteUrl }}js/owl-carousel/owl.carousel.min.js\"></script>
      <script src=\"{{ siteUrl }}js/swiper/swiper.min.js\"></script>
      <script src=\"{{ siteUrl }}js/swiperanimation/SwiperAnimation.min.js\"></script>
      <script src=\"{{ siteUrl }}js/magnific-popup/jquery.magnific-popup.min.js\"></script>
      <script src=\"{{ siteUrl }}js/counter/jquery.countTo.js\"></script>

      <!-- Template Scripts (Do not remove)-->
      <script src=\"{{ siteUrl }}js/custom.js\"></script>
      
    </body>
  </html>", "index", "/var/www/html/templates/index.twig");
    }
}

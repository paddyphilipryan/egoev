<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* components/banner */
class __TwigTemplate_8bc68f00751b42cb5dcd54127aba5af830da69710337d0654f8e6e6260022a7a extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "components/banner");
        // line 1
        echo "<!--=================================
      Ev car area -->
      <section class=\"ev-car-section bg-overlay-black-2 bg-holder\" style=\"background-image: url(./images/home-03/bg-01.jpg);\">
        <div class=\"container\">
          <div class=\"row\">
            <div class=\"col-lg-12\">
              <div class=\"ev-car-area\">
                <div class=\"car-area\">
                  <h2> </h2>
                  <span> </span>
                </div>
              <div class=\"car-area\">
                  <h2> </h2>
                  <span> </span>
                </div>
                <div class=\"car-area\">
                  <h2> </h2>
                  <span> </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!--=================================
      Ev car area -->";
        craft\helpers\Template::endProfile("template", "components/banner");
    }

    public function getTemplateName()
    {
        return "components/banner";
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!--=================================
      Ev car area -->
      <section class=\"ev-car-section bg-overlay-black-2 bg-holder\" style=\"background-image: url(./images/home-03/bg-01.jpg);\">
        <div class=\"container\">
          <div class=\"row\">
            <div class=\"col-lg-12\">
              <div class=\"ev-car-area\">
                <div class=\"car-area\">
                  <h2> </h2>
                  <span> </span>
                </div>
              <div class=\"car-area\">
                  <h2> </h2>
                  <span> </span>
                </div>
                <div class=\"car-area\">
                  <h2> </h2>
                  <span> </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!--=================================
      Ev car area -->", "components/banner", "/var/www/html/templates/components/banner.twig");
    }
}

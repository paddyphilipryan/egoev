<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* components/services */
class __TwigTemplate_45691ec51fd5b090794f6731531709812f9d7f88905c3a85fda920a1419c44fe extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "components/services");
        craft\helpers\Template::preloadSingles(['entry']);
        // line 1
        echo "<!--=================================
      Our Services-->
      <!--=================================
      Section-->
      <section class=\"bg-light position-relative\">
        <div class=\"container\">
          <div class=\"row justify-content-end\">
              <div class=\"col-lg-6 position-absolute start-0 top-0 h-100 p-0 pe-5 d-none d-lg-flex\" >
                 <div class=\"img-fluid h-100 w-100\" style=\"background-image: url(./images/home-02/03.jpg); background-size:cover;background-repeat:no-repeat;background-position:center;\">
                 </div>
              </div>
            <div class=\"col-lg-6 justify-content-start align-items-center d-flex\">
              <div class=\"space-ptb\">
                <div class=\"section-title\">
                  <h2>";
        // line 15
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 15, $this->source); })())), "installHeader", []), "html", null, true);
        echo "</h2>
                  <p>";
        // line 16
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 16, $this->source); })())), "installBody", []), "html", null, true);
        echo "</p>
                </div>
                <div class=\"list d-sm-flex mb-3\">
                  <ul class=\"list-unstyled me-5\">
                  ";
        // line 20
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 20, $this->source); })())), "installBullets", []), "html", null, true);
        echo "
                  </ul>
                </div>
                <a href=\"#\" class=\"btn btn-primary mt-2\">Installation</a>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!--=================================
      Section-->";
        craft\helpers\Template::endProfile("template", "components/services");
    }

    public function getTemplateName()
    {
        return "components/services";
    }

    public function getDebugInfo()
    {
        return array (  66 => 20,  59 => 16,  55 => 15,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!--=================================
      Our Services-->
      <!--=================================
      Section-->
      <section class=\"bg-light position-relative\">
        <div class=\"container\">
          <div class=\"row justify-content-end\">
              <div class=\"col-lg-6 position-absolute start-0 top-0 h-100 p-0 pe-5 d-none d-lg-flex\" >
                 <div class=\"img-fluid h-100 w-100\" style=\"background-image: url(./images/home-02/03.jpg); background-size:cover;background-repeat:no-repeat;background-position:center;\">
                 </div>
              </div>
            <div class=\"col-lg-6 justify-content-start align-items-center d-flex\">
              <div class=\"space-ptb\">
                <div class=\"section-title\">
                  <h2>{{ entry.installHeader }}</h2>
                  <p>{{ entry.installBody }}</p>
                </div>
                <div class=\"list d-sm-flex mb-3\">
                  <ul class=\"list-unstyled me-5\">
                  {{ entry.installBullets }}
                  </ul>
                </div>
                <a href=\"#\" class=\"btn btn-primary mt-2\">Installation</a>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!--=================================
      Section-->", "components/services", "/var/www/html/templates/components/services.twig");
    }
}

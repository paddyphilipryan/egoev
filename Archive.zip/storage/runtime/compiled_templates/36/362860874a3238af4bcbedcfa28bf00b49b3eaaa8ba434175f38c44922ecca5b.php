<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* components/test1 */
class __TwigTemplate_07045566cf552fe2acd08e3cf8e0e0779f1934ee753617c4cfdf31e57d054694 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "components/test1");
        craft\helpers\Template::preloadSingles(['entry', 'testimonials', 'photo']);
        // line 1
        echo " <!--=================================
      Testimonial -->
      <section class=\"bg-light position-relative testimonial-light-bg\">
        <div class=\"container-fluid\">
          <div class=\"row\">
            <div class=\"col-lg-6 testimonial-bg\" style=\"background-image: url(./images/testimonial/01.jpg);background-size:cover;background-repeat:no-repeat;background-position:center\">
            </div>
            <div class=\"col-lg-6 justify-content-start\">
              <div class=\"space-ptb testimonial-description\">
                <div class=\"section-title left-divider\">
                <span>";
        // line 11
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 11, $this->source); })())), "testimonialsSubtitle", []), "html", null, true);
        echo "</span>
                <h2> ";
        // line 12
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 12, $this->source); })())), "testimonialsTitle", []), "html", null, true);
        echo "</h2>
              </div>
                ";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 14, $this->source); })())), "testimonials", []), "all", [], "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["testimonials"]) {
            // line 15
            echo "                ";
            $context["photo"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["testimonials"], "personImage", []), "one", [], "method");
            echo "<div class=\"owl-carousel owl-nav-bottom-center ps-0\" data-nav-dots=\"false\" data-nav-arrow=\"true\" data-items=\"1\" data-lg-items=\"1\" data-md-items=\"1\" data-sm-items=\"1\"  data-space=\"30\" data-autoheight=\"true\">
                  <div class=\"item\">
                    <div class=\"testimonial\">
                    
                      <div class=\"testimonial-quote-icon\">
                        <img class=\"img-fluid\" src=\"images/testimonial/quote.svg\" alt=\"\">
                      </div>
                      <div class=\"testimonial-content\">
                        <p class=\"mb-0\"><i>";
            // line 23
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["testimonials"], "comment", []), "html", null, true);
            echo "</i> </p>
                      </div>
                      <div class=\"testimonial-author info-right\">
                        <div class=\"testimonial-avatar avatar\">
                          <img class=\"img-fluid\" src=\"";
            // line 27
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["photo"]) || array_key_exists("photo", $context) ? $context["photo"] : (craft\helpers\Template::fallbackExists("photo") ? craft\helpers\Template::fallback("photo") : (function () { throw new RuntimeError('Variable "photo" does not exist.', 27, $this->source); })())), "url", []), "html", null, true);
            echo "\" alt=\"\">
                        </div>
                        <div class=\"testimonial-name\">
                          <h6 class=\"author-tittle\">";
            // line 30
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["testimonials"], "person", []), "html", null, true);
            echo "</h6>
                          <span>";
            // line 31
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["testimonials"], "personTitle", []), "html", null, true);
            echo "</span>
                        </div>
                      </div>
                      
                    </div>
        
                  </div>
                  ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['testimonials'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 39
        echo "                </div>
                
              </div>
            </div>
          </div>
        </div>
      </section>
      <!--=================================
      Testimonial -->";
        craft\helpers\Template::endProfile("template", "components/test1");
    }

    public function getTemplateName()
    {
        return "components/test1";
    }

    public function getDebugInfo()
    {
        return array (  107 => 39,  93 => 31,  89 => 30,  83 => 27,  76 => 23,  64 => 15,  60 => 14,  55 => 12,  51 => 11,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source(" <!--=================================
      Testimonial -->
      <section class=\"bg-light position-relative testimonial-light-bg\">
        <div class=\"container-fluid\">
          <div class=\"row\">
            <div class=\"col-lg-6 testimonial-bg\" style=\"background-image: url(./images/testimonial/01.jpg);background-size:cover;background-repeat:no-repeat;background-position:center\">
            </div>
            <div class=\"col-lg-6 justify-content-start\">
              <div class=\"space-ptb testimonial-description\">
                <div class=\"section-title left-divider\">
                <span>{{ entry.testimonialsSubtitle }}</span>
                <h2> {{ entry.testimonialsTitle }}</h2>
              </div>
                {% for testimonials in entry.testimonials.all() %}
                {% set photo = testimonials.personImage.one() %}<div class=\"owl-carousel owl-nav-bottom-center ps-0\" data-nav-dots=\"false\" data-nav-arrow=\"true\" data-items=\"1\" data-lg-items=\"1\" data-md-items=\"1\" data-sm-items=\"1\"  data-space=\"30\" data-autoheight=\"true\">
                  <div class=\"item\">
                    <div class=\"testimonial\">
                    
                      <div class=\"testimonial-quote-icon\">
                        <img class=\"img-fluid\" src=\"images/testimonial/quote.svg\" alt=\"\">
                      </div>
                      <div class=\"testimonial-content\">
                        <p class=\"mb-0\"><i>{{ testimonials.comment }}</i> </p>
                      </div>
                      <div class=\"testimonial-author info-right\">
                        <div class=\"testimonial-avatar avatar\">
                          <img class=\"img-fluid\" src=\"{{ photo.url }}\" alt=\"\">
                        </div>
                        <div class=\"testimonial-name\">
                          <h6 class=\"author-tittle\">{{ testimonials.person }}</h6>
                          <span>{{ testimonials.personTitle }}</span>
                        </div>
                      </div>
                      
                    </div>
        
                  </div>
                  {% endfor %}
                </div>
                
              </div>
            </div>
          </div>
        </div>
      </section>
      <!--=================================
      Testimonial -->", "components/test1", "/var/www/html/templates/components/test1.twig");
    }
}

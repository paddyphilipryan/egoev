<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms/button */
class __TwigTemplate_316248b8122e970781e4656ad1d6c240a778166648bb5631b4fba38fd5bbc4c2 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/button");
        // line 1
        $context["spinner"] = (($context["spinner"]) ?? (false));
        // line 2
        $context["busyMessage"] = (($context["busyMessage"]) ?? (false));
        // line 3
        $context["failureMessage"] = (($context["failureMessage"]) ?? (false));
        // line 4
        $context["retryMessage"] = (($context["retryMessage"]) ?? (false));
        // line 5
        $context["successMessage"] = (($context["successMessage"]) ?? (false));
        // line 6
        $context["label"] = (($context["label"]) ?? (null));
        // line 7
        $context["attributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["type" => ((        // line 8
$context["type"]) ?? ("button")), "id" => ((        // line 9
$context["id"]) ?? (false)), "class" => $this->extensions['craft\web\twig\Extension']->mergeFilter(craft\helpers\Html::explodeClass(((        // line 10
$context["class"]) ?? ([]))), $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => "btn", 1 => (( !        // line 12
(isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 12, $this->source); })())) ? ("btn-empty") : (null))])), "data" => ["busy-message" =>         // line 15
(isset($context["busyMessage"]) || array_key_exists("busyMessage", $context) ? $context["busyMessage"] : (function () { throw new RuntimeError('Variable "busyMessage" does not exist.', 15, $this->source); })()), "failure-message" =>         // line 16
(isset($context["failureMessage"]) || array_key_exists("failureMessage", $context) ? $context["failureMessage"] : (function () { throw new RuntimeError('Variable "failureMessage" does not exist.', 16, $this->source); })()), "retry-message" =>         // line 17
(isset($context["retryMessage"]) || array_key_exists("retryMessage", $context) ? $context["retryMessage"] : (function () { throw new RuntimeError('Variable "retryMessage" does not exist.', 17, $this->source); })()), "success-message" =>         // line 18
(isset($context["successMessage"]) || array_key_exists("successMessage", $context) ? $context["successMessage"] : (function () { throw new RuntimeError('Variable "successMessage" does not exist.', 18, $this->source); })())]], ((        // line 20
$context["attributes"]) ?? ([])));
        // line 22
        ob_start();
        // line 23
        echo "    ";
        if ((isset($context["spinner"]) || array_key_exists("spinner", $context) ? $context["spinner"] : (function () { throw new RuntimeError('Variable "spinner" does not exist.', 23, $this->source); })())) {
            // line 24
            echo "        <div role=\"status\" class=\"visually-hidden\"></div>
    ";
        }
        // line 26
        echo "    ";
        ob_start();
        // line 27
        echo "        ";
        echo (((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 27, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->tagFunction("div", ["class" => "label", "text" =>         // line 29
(isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 29, $this->source); })())])) : (""));
        // line 30
        echo "
        ";
        // line 31
        if ((isset($context["spinner"]) || array_key_exists("spinner", $context) ? $context["spinner"] : (function () { throw new RuntimeError('Variable "spinner" does not exist.', 31, $this->source); })())) {
            // line 32
            echo "            <div class=\"spinner spinner-absolute\">
                <span class=\"visually-hidden\">";
            // line 33
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Loading", "app"), "html", null, true);
            echo "</span>
            </div>
        ";
        }
        // line 36
        echo "    ";
        echo craft\helpers\Html::tag("button", ob_get_clean(),         // line 26
(isset($context["attributes"]) || array_key_exists("attributes", $context) ? $context["attributes"] : (function () { throw new RuntimeError('Variable "attributes" does not exist.', 26, $this->source); })()));
        $___internal_parse_1_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 22
        echo twig_spaceless($___internal_parse_1_);
        craft\helpers\Template::endProfile("template", "_includes/forms/button");
    }

    public function getTemplateName()
    {
        return "_includes/forms/button";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 22,  93 => 26,  91 => 36,  85 => 33,  82 => 32,  80 => 31,  77 => 30,  75 => 29,  73 => 27,  70 => 26,  66 => 24,  63 => 23,  61 => 22,  59 => 20,  58 => 18,  57 => 17,  56 => 16,  55 => 15,  54 => 12,  53 => 10,  52 => 9,  51 => 8,  50 => 7,  48 => 6,  46 => 5,  44 => 4,  42 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% set spinner = spinner ?? false -%}
{% set busyMessage = busyMessage ?? false %}
{% set failureMessage = failureMessage ?? false %}
{% set retryMessage = retryMessage ?? false %}
{% set successMessage = successMessage ?? false %}
{% set label = label ?? null %}
{% set attributes = {
    type: type ?? 'button',
    id: id ?? false,
    class: (class ?? [])|explodeClass|merge([
        'btn',
        not label ? 'btn-empty' : null,
    ]|filter),
    data: {
        'busy-message': busyMessage,
        'failure-message': failureMessage,
        'retry-message': retryMessage,
        'success-message': successMessage,
    }
}|merge(attributes ?? {}) -%}

{% apply spaceless %}
    {% if spinner %}
        <div role=\"status\" class=\"visually-hidden\"></div>
    {% endif %}
    {% tag 'button' with attributes %}
        {{ label ? tag('div', {
            class: 'label',
            text: label,
        }) }}
        {% if spinner %}
            <div class=\"spinner spinner-absolute\">
                <span class=\"visually-hidden\">{{ 'Loading'|t('app') }}</span>
            </div>
        {% endif %}
    {% endtag %}
{% endapply -%}
", "_includes/forms/button", "/var/www/html/vendor/craftcms/cms/src/templates/_includes/forms/button.twig");
    }
}

<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* components/blog */
class __TwigTemplate_ca47997c88c59efef702be975094d63126e7279f9ac2711d2057b3914ea9414c extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "components/blog");
        craft\helpers\Template::preloadSingles(['craft', 'blogs', 'blog', 'photo']);
        // line 1
        echo "<!--=================================
      Blog -->
      <section class=\"space-ptb\">
        <div class=\"container\">
          <div class=\"row d-flex align-items-center mb-4 mb-lg-5\">
            <div class=\"col-md-12 col-lg-8 col-xl-6\">
              <div class=\"section-title left-divider mb-0\">
                <span>RECENT ARTICLES</span>
                <h2>Recent articles and news</h2>
              </div>
            </div>
            <div class=\"col-md-12 col-lg-4 col-xl-6 text-lg-end text-start mt-4 mt-lg-0\">
              <a href=\"#\" class=\"btn btn-link text-secondary\">Let's talk <i class=\"fa-solid fa-arrow-right-long ms-2\"></i></a>
            </div>
          </div>
          <div class=\"row\">
          ";
        // line 17
        $context["blogs"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (craft\helpers\Template::fallbackExists("craft") ? craft\helpers\Template::fallback("craft") : (function () { throw new RuntimeError('Variable "craft" does not exist.', 17, $this->source); })())), "entries", []), "section", [0 => "blogs"], "method"), "limit", [0 => 3], "method");
        // line 18
        echo "          ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["blogs"]) || array_key_exists("blogs", $context) ? $context["blogs"] : (craft\helpers\Template::fallbackExists("blogs") ? craft\helpers\Template::fallback("blogs") : (function () { throw new RuntimeError('Variable "blogs" does not exist.', 18, $this->source); })())));
        foreach ($context['_seq'] as $context["_key"] => $context["blog"]) {
            echo " 
          ";
            // line 19
            $context["photo"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["blog"], "featuredImage", []), "one", [], "method");
            // line 20
            echo "            <div class=\"col-lg-4 col-md-6\">
              <div class=\"blog-post blog-style-02 mb-0\">
                <div class=\"blog-img\">
                  <a href=\"";
            // line 23
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["blog"], "url", []), "html", null, true);
            echo "\"><img class=\"img-fluid\" src=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["photo"]) || array_key_exists("photo", $context) ? $context["photo"] : (craft\helpers\Template::fallbackExists("photo") ? craft\helpers\Template::fallback("photo") : (function () { throw new RuntimeError('Variable "photo" does not exist.', 23, $this->source); })())), "url", []), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["blog"], "title", []), "html", null, true);
            echo "\"></a>
                </div>
                  <div class=\"blog-info\">
                    <span>";
            // line 26
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->dateFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["blog"], "postDate", []), "d/M/Y"), "html", null, true);
            echo "</span>
                    <h4 class=\"blog-tittle\"><a href=\"";
            // line 27
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["blog"], "url", []), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["blog"], "title", []), "html", null, true);
            echo "</a></h4>
                    <a class=\"blog-link\" href=\"";
            // line 28
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["blog"], "url", []), "html", null, true);
            echo "\">Read More<i class=\"fa-solid fa-arrow-right-long ps-2\"></i></a>
                  </div>
              </div>
            </div>
          ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['blog'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 33
        echo "          </div>
        </div>
      </section>
      <!--=================================
      Blog -->
";
        craft\helpers\Template::endProfile("template", "components/blog");
    }

    public function getTemplateName()
    {
        return "components/blog";
    }

    public function getDebugInfo()
    {
        return array (  104 => 33,  93 => 28,  87 => 27,  83 => 26,  73 => 23,  68 => 20,  66 => 19,  59 => 18,  57 => 17,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!--=================================
      Blog -->
      <section class=\"space-ptb\">
        <div class=\"container\">
          <div class=\"row d-flex align-items-center mb-4 mb-lg-5\">
            <div class=\"col-md-12 col-lg-8 col-xl-6\">
              <div class=\"section-title left-divider mb-0\">
                <span>RECENT ARTICLES</span>
                <h2>Recent articles and news</h2>
              </div>
            </div>
            <div class=\"col-md-12 col-lg-4 col-xl-6 text-lg-end text-start mt-4 mt-lg-0\">
              <a href=\"#\" class=\"btn btn-link text-secondary\">Let's talk <i class=\"fa-solid fa-arrow-right-long ms-2\"></i></a>
            </div>
          </div>
          <div class=\"row\">
          {% set blogs = craft.entries.section('blogs').limit(3) %}
          {% for blog in blogs %} 
          {% set photo = blog.featuredImage.one() %}
            <div class=\"col-lg-4 col-md-6\">
              <div class=\"blog-post blog-style-02 mb-0\">
                <div class=\"blog-img\">
                  <a href=\"{{ blog.url }}\"><img class=\"img-fluid\" src=\"{{ photo.url }}\" alt=\"{{ blog.title }}\"></a>
                </div>
                  <div class=\"blog-info\">
                    <span>{{blog.postDate|date('d/M/Y')}}</span>
                    <h4 class=\"blog-tittle\"><a href=\"{{ blog.url }}\">{{ blog.title }}</a></h4>
                    <a class=\"blog-link\" href=\"{{ blog.url }}\">Read More<i class=\"fa-solid fa-arrow-right-long ps-2\"></i></a>
                  </div>
              </div>
            </div>
          {% endfor %}
          </div>
        </div>
      </section>
      <!--=================================
      Blog -->
", "components/blog", "/var/www/html/templates/components/blog.twig");
    }
}

<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _elements/sources */
class __TwigTemplate_fe8f679002de01d44b2175d754c9e42327b4a5d30b692f0110db8f82ba95cff5 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $macros["_self"] = $this->macros["_self"] = $this;
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_elements/sources");
        // line 1
        ob_start();
        // line 2
        $context["keyPrefix"] = (($context["keyPrefix"]) ?? (""));
        // line 3
        $context["isTopLevel"] =  !(isset($context["keyPrefix"]) || array_key_exists("keyPrefix", $context) ? $context["keyPrefix"] : (function () { throw new RuntimeError('Variable "keyPrefix" does not exist.', 3, $this->source); })());
        // line 4
        echo "
";
        // line 5
        if ((isset($context["isTopLevel"]) || array_key_exists("isTopLevel", $context) ? $context["isTopLevel"] : (function () { throw new RuntimeError('Variable "isTopLevel" does not exist.', 5, $this->source); })())) {
            // line 6
            echo "    ";
            $context["elementInstance"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 6, $this->source); })()), "app", []), "elements", []), "createElement", [0 => (isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 6, $this->source); })())], "method");
            // line 7
            echo "    ";
            $context["baseSortOptions"] = array_values(twig_array_map($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["elementInstance"]) || array_key_exists("elementInstance", $context) ? $context["elementInstance"] : (function () { throw new RuntimeError('Variable "elementInstance" does not exist.', 7, $this->source); })()), "sortOptions", [], "method"), function ($__option__, $__key__) use ($context, $macros) { $context["option"] = $__option__; $context["key"] = $__key__; return ["label" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 8
($context["option"] ?? null), "label", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["option"] ?? null), "label", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["option"] ?? null), "label", [])) : ((isset($context["option"]) || array_key_exists("option", $context) ? $context["option"] : (function () { throw new RuntimeError('Variable "option" does not exist.', 8, $this->source); })()))), "attr" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 9
($context["option"] ?? null), "attribute", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["option"] ?? null), "attribute", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["option"] ?? null), "attribute", [])) : ((((craft\helpers\Template::attribute($this->env, $this->source, ($context["option"] ?? null), "orderBy", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["option"] ?? null), "orderBy", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["option"] ?? null), "orderBy", [])) : ((isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 9, $this->source); })()))))), "defaultDir" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 10
($context["option"] ?? null), "defaultDir", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["option"] ?? null), "defaultDir", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["option"] ?? null), "defaultDir", [])) : ("asc"))]; }));
            // line 12
            echo "    ";
            $context["tableColumns"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 12, $this->source); })()), "app", []), "elementSources", []), "getAvailableTableAttributes", [0 => (isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 12, $this->source); })())], "method");
        }
        // line 14
        echo "
";
        // line 50
        echo "
";
        // line 77
        echo "
";
        // line 78
        $context["nestedUnderHeading"] = false;
        // line 79
        echo "
";
        // line 80
        ob_start();
        // line 83
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["sources"]) || array_key_exists("sources", $context) ? $context["sources"] : (function () { throw new RuntimeError('Variable "sources" does not exist.', 83, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["source"]) {
            // line 84
            echo "        ";
            if (((((craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "type", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "type", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "type", [])) : (null)) == "heading")) {
                // line 85
                echo "            ";
                if ((isset($context["nestedUnderHeading"]) || array_key_exists("nestedUnderHeading", $context) ? $context["nestedUnderHeading"] : (function () { throw new RuntimeError('Variable "nestedUnderHeading" does not exist.', 85, $this->source); })())) {
                    // line 86
                    echo "                    </ul>
                </li>
            ";
                }
                // line 89
                echo "            <li class=\"heading\">
                <span>";
                // line 90
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "heading", []), "site"), "html", null, true);
                echo "</span>
                <ul>
            ";
                // line 92
                $context["nestedUnderHeading"] = true;
                // line 93
                echo "        ";
            } else {
                // line 94
                echo "            ";
                $context["key"] = (((craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "keyPath", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "keyPath", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "keyPath", [])) : (((isset($context["keyPrefix"]) || array_key_exists("keyPrefix", $context) ? $context["keyPrefix"] : (function () { throw new RuntimeError('Variable "keyPrefix" does not exist.', 94, $this->source); })()) . craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "key", []))));
                // line 95
                echo "            ";
                ob_start();
                // line 100
                echo "                ";
                echo twig_call_macro($macros["_self"], "macro_sourceLink", [(isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 100, $this->source); })()), $context["source"], (isset($context["isTopLevel"]) || array_key_exists("isTopLevel", $context) ? $context["isTopLevel"] : (function () { throw new RuntimeError('Variable "isTopLevel" does not exist.', 100, $this->source); })()), (isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 100, $this->source); })()), (($context["baseSortOptions"]) ?? (null)), (($context["tableColumns"]) ?? (null))], 100, $context, $this->getSourceContext());
                echo "
                ";
                // line 101
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "nested", [], "any", true, true) &&  !twig_test_empty(craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "nested", [])))) {
                    // line 102
                    echo "                    <button class=\"toggle\" aria-expanded=\"false\" aria-label=\"";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Show nested sources", "app"), "html", null, true);
                    echo "\"></button>
                    ";
                    // line 103
                    $this->loadTemplate("_elements/sources", "_elements/sources", 103)->display(twig_array_merge($context, ["keyPrefix" => (                    // line 104
(isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 104, $this->source); })()) . "/"), "sources" => craft\helpers\Template::attribute($this->env, $this->source,                     // line 105
$context["source"], "nested", [])]));
                    // line 107
                    echo "                ";
                }
                // line 108
                echo "            ";
                echo craft\helpers\Html::tag("li", ob_get_clean(), ["class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => (((((craft\helpers\Template::attribute($this->env, $this->source,                 // line 97
$context["source"], "disabled", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "disabled", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "disabled", [])) : (false))) ? ("hidden") : (null))])]);
                // line 109
                echo "        ";
            }
            // line 110
            echo "    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['source'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 111
        echo "    ";
        if ((isset($context["nestedUnderHeading"]) || array_key_exists("nestedUnderHeading", $context) ? $context["nestedUnderHeading"] : (function () { throw new RuntimeError('Variable "nestedUnderHeading" does not exist.', 111, $this->source); })())) {
            // line 112
            echo "            </ul>
        </li>
    ";
        }
        echo craft\helpers\Html::tag("ul", ob_get_clean(), ["class" => ((        // line 81
(isset($context["keyPrefix"]) || array_key_exists("keyPrefix", $context) ? $context["keyPrefix"] : (function () { throw new RuntimeError('Variable "keyPrefix" does not exist.', 81, $this->source); })())) ? ("nested") : (null))]);
        $___internal_parse_0_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 1
        echo twig_spaceless($___internal_parse_0_);
        craft\helpers\Template::endProfile("template", "_elements/sources");
    }

    // line 15
    public function macro_sourceLink($__key__ = null, $__source__ = null, $__isTopLevel__ = null, $__elementType__ = null, $__baseSortOptions__ = null, $__tableColumns__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "key" => $__key__,
            "source" => $__source__,
            "isTopLevel" => $__isTopLevel__,
            "elementType" => $__elementType__,
            "baseSortOptions" => $__baseSortOptions__,
            "tableColumns" => $__tableColumns__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "sourceLink");
            // line 16
            echo "    ";
            echo $this->extensions['craft\web\twig\Extension']->tagFunction("a", ["data" => $this->extensions['craft\web\twig\Extension']->mergeFilter(["key" =>             // line 18
(isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 18, $this->source); })()), "has-thumbs" => (((((craft\helpers\Template::attribute($this->env, $this->source,             // line 19
($context["source"] ?? null), "hasThumbs", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "hasThumbs", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "hasThumbs", [])) : (false))) ? (true) : (false)), "has-structure" => boolval((((craft\helpers\Template::attribute($this->env, $this->source,             // line 20
($context["source"] ?? null), "structureId", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "structureId", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "structureId", [])) : (null))), "default-sort" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 21
($context["source"] ?? null), "defaultSort", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "defaultSort", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "defaultSort", [])) : (false)), "sort-opts" => ((            // line 22
(isset($context["isTopLevel"]) || array_key_exists("isTopLevel", $context) ? $context["isTopLevel"] : (function () { throw new RuntimeError('Variable "isTopLevel" does not exist.', 22, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->mergeFilter(            // line 23
(isset($context["baseSortOptions"]) || array_key_exists("baseSortOptions", $context) ? $context["baseSortOptions"] : (function () { throw new RuntimeError('Variable "baseSortOptions" does not exist.', 23, $this->source); })()), array_values(twig_array_map($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,             // line 24
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 24, $this->source); })()), "app", []), "elementSources", []), "getSourceSortOptions", [0 => (isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 24, $this->source); })()), 1 => (isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 24, $this->source); })())], "method"), function ($__option__) use ($context, $macros) { $context["option"] = $__option__; return ["label" => craft\helpers\Template::attribute($this->env, $this->source,             // line 25
(isset($context["option"]) || array_key_exists("option", $context) ? $context["option"] : (function () { throw new RuntimeError('Variable "option" does not exist.', 25, $this->source); })()), "label", []), "attr" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 26
($context["option"] ?? null), "attribute", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["option"] ?? null), "attribute", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["option"] ?? null), "attribute", [])) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["option"]) || array_key_exists("option", $context) ? $context["option"] : (function () { throw new RuntimeError('Variable "option" does not exist.', 26, $this->source); })()), "orderBy", []))), "defaultDir" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 27
($context["option"] ?? null), "defaultDir", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["option"] ?? null), "defaultDir", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["option"] ?? null), "defaultDir", [])) : ("asc"))]; })))) : (false)), "table-col-opts" => ((            // line 30
(isset($context["isTopLevel"]) || array_key_exists("isTopLevel", $context) ? $context["isTopLevel"] : (function () { throw new RuntimeError('Variable "isTopLevel" does not exist.', 30, $this->source); })())) ? (array_values(twig_array_map($this->env, $this->extensions['craft\web\twig\Extension']->mergeFilter(            // line 31
(isset($context["tableColumns"]) || array_key_exists("tableColumns", $context) ? $context["tableColumns"] : (function () { throw new RuntimeError('Variable "tableColumns" does not exist.', 31, $this->source); })()), craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,             // line 32
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 32, $this->source); })()), "app", []), "elementSources", []), "getSourceTableAttributes", [0 => (isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 32, $this->source); })()), 1 => (isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 32, $this->source); })())], "method")),             // line 33
function ($__a__, $__key__) use ($context, $macros) { $context["a"] = $__a__; $context["key"] = $__key__; return $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["a"]) || array_key_exists("a", $context) ? $context["a"] : (function () { throw new RuntimeError('Variable "a" does not exist.', 33, $this->source); })()), ["attr" => (isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 33, $this->source); })())]); }))) : (false)), "default-table-cols" => ((            // line 36
(isset($context["isTopLevel"]) || array_key_exists("isTopLevel", $context) ? $context["isTopLevel"] : (function () { throw new RuntimeError('Variable "isTopLevel" does not exist.', 36, $this->source); })())) ? (array_values($this->extensions['craft\web\twig\Extension']->filterFilter($this->env, twig_array_map($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,             // line 37
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 37, $this->source); })()), "app", []), "elementSources", []), "getTableAttributes", [0 => (isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 37, $this->source); })()), 1 => (isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 37, $this->source); })())], "method"),             // line 38
function ($__a__) use ($context, $macros) { $context["a"] = $__a__; return craft\helpers\Template::attribute($this->env, $this->source, (isset($context["a"]) || array_key_exists("a", $context) ? $context["a"] : (function () { throw new RuntimeError('Variable "a" does not exist.', 38, $this->source); })()), 0, [], "array"); }),             // line 39
function ($__a__) use ($context, $macros) { $context["a"] = $__a__; return ((isset($context["a"]) || array_key_exists("a", $context) ? $context["a"] : (function () { throw new RuntimeError('Variable "a" does not exist.', 39, $this->source); })()) != "title"); }))) : (false)), "default-source-path" => (((((craft\helpers\Template::attribute($this->env, $this->source,             // line 42
($context["source"] ?? null), "defaultSourcePath", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "defaultSourcePath", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "defaultSourcePath", [])) : (false))) ? ($this->extensions['craft\web\twig\Extension']->jsonEncodeFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 42, $this->source); })()), "defaultSourcePath", []))) : (false)), "sites" => (((((craft\helpers\Template::attribute($this->env, $this->source,             // line 43
($context["source"] ?? null), "sites", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "sites", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "sites", [])) : (false))) ? (twig_join_filter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 43, $this->source); })()), "sites", []), ",")) : (false)), "override-status" => (((((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,             // line 44
($context["source"] ?? null), "criteria", [], "any", false, true), "status", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "criteria", [], "any", false, true), "status", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "criteria", [], "any", false, true), "status", [])) : (false))) ? (true) : (false)), "disabled" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 45
($context["source"] ?? null), "disabled", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "disabled", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "disabled", [])) : (false))], (((craft\helpers\Template::attribute($this->env, $this->source,             // line 46
($context["source"] ?? null), "data", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "data", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "data", [])) : ([]))), "html" => twig_call_macro($macros["_self"], "macro_sourceInnerHtml", [            // line 47
(isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 47, $this->source); })())], 47, $context, $this->getSourceContext())]);
            // line 48
            echo "
";
            craft\helpers\Template::endProfile("macro", "sourceLink");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 51
    public function macro_sourceInnerHtml($__source__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "source" => $__source__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "sourceInnerHtml");
            // line 52
            echo "    ";
            if (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "status", [], "any", true, true)) {
                // line 53
                echo "        <span class=\"status ";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 53, $this->source); })()), "status", []), "html", null, true);
                echo "\"></span>
    ";
            } elseif (craft\helpers\Template::attribute($this->env, $this->source,             // line 54
($context["source"] ?? null), "icon", [], "any", true, true)) {
                // line 55
                echo "        <span class=\"icon\">
            ";
                // line 56
                echo (($this->extensions['craft\web\twig\Extension']->svgFunction(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 56, $this->source); })()), "icon", []), true, true)) ? ($this->extensions['craft\web\twig\Extension']->svgFunction(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 56, $this->source); })()), "icon", []), true, true)) : ((("<span data-icon='" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 56, $this->source); })()), "icon", [])) . "'></span>")));
                echo "
        </span>
    ";
            } elseif (craft\helpers\Template::attribute($this->env, $this->source,             // line 58
($context["source"] ?? null), "iconMask", [], "any", true, true)) {
                // line 59
                echo "        <span class=\"icon icon-mask\">
            ";
                // line 60
                echo (($this->extensions['craft\web\twig\Extension']->svgFunction(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 60, $this->source); })()), "iconMask", []), true, true)) ? ($this->extensions['craft\web\twig\Extension']->svgFunction(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 60, $this->source); })()), "iconMask", []), true, true)) : ((("<span data-icon='" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 60, $this->source); })()), "iconMask", [])) . "'></span>")));
                echo "
        </span>
    ";
            }
            // line 63
            echo "    <span class=\"label\">";
            echo twig_escape_filter($this->env, (( !(twig_trim_filter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 63, $this->source); })()), "label", [])) === "")) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 63, $this->source); })()), "label", [])) : ($this->extensions['craft\web\twig\Extension']->translateFilter("(blank)", "app"))), "html", null, true);
            echo "</span>
    ";
            // line 64
            if (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "badgeCount", [], "any", true, true)) {
                // line 65
                echo "        <span class=\"badge\" aria-hidden=\"true\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->numberFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 65, $this->source); })()), "badgeCount", []), 0), "html", null, true);
                echo "</span>
        ";
                // line 66
                echo $this->extensions['craft\web\twig\Extension']->tagFunction("span", ["class" => "visually-hidden", "data" => ["notification" => true], "text" => $this->extensions['craft\web\twig\Extension']->translateFilter("{num, number} {num, plural, =1{notification} other{notifications}}", "app", ["num" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 72
(isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 72, $this->source); })()), "badgeCount", [])])]);
                // line 74
                echo "
    ";
            }
            craft\helpers\Template::endProfile("macro", "sourceInnerHtml");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "_elements/sources";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  298 => 74,  296 => 72,  295 => 66,  290 => 65,  288 => 64,  283 => 63,  277 => 60,  274 => 59,  272 => 58,  267 => 56,  264 => 55,  262 => 54,  257 => 53,  254 => 52,  240 => 51,  229 => 48,  227 => 47,  226 => 46,  225 => 45,  224 => 44,  223 => 43,  222 => 42,  221 => 39,  220 => 38,  219 => 37,  218 => 36,  217 => 33,  216 => 32,  215 => 31,  214 => 30,  213 => 27,  212 => 26,  211 => 25,  210 => 24,  209 => 23,  208 => 22,  207 => 21,  206 => 20,  205 => 19,  204 => 18,  202 => 16,  183 => 15,  178 => 1,  175 => 81,  170 => 112,  167 => 111,  153 => 110,  150 => 109,  148 => 97,  146 => 108,  143 => 107,  141 => 105,  140 => 104,  139 => 103,  134 => 102,  132 => 101,  127 => 100,  124 => 95,  121 => 94,  118 => 93,  116 => 92,  111 => 90,  108 => 89,  103 => 86,  100 => 85,  97 => 84,  79 => 83,  77 => 80,  74 => 79,  72 => 78,  69 => 77,  66 => 50,  63 => 14,  59 => 12,  57 => 10,  56 => 9,  55 => 8,  53 => 7,  50 => 6,  48 => 5,  45 => 4,  43 => 3,  41 => 2,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% apply spaceless %}
{% set keyPrefix = keyPrefix ?? '' %}
{% set isTopLevel = not keyPrefix %}

{% if isTopLevel %}
    {% set elementInstance = craft.app.elements.createElement(elementType) %}
    {% set baseSortOptions = elementInstance.sortOptions()|map((option, key) => {
        label: option.label ?? option,
        attr: option.attribute ?? option.orderBy ?? key,
        defaultDir: option.defaultDir ?? 'asc',
    })|values %}
    {% set tableColumns = craft.app.elementSources.getAvailableTableAttributes(elementType) %}
{% endif %}

{% macro sourceLink(key, source, isTopLevel, elementType, baseSortOptions, tableColumns) %}
    {{ tag('a', {
        data: {
            key: key,
            'has-thumbs': (source.hasThumbs ?? false) ? true : false,
            'has-structure': (source.structureId ?? null)|boolean,
            'default-sort': source.defaultSort ?? false,
            'sort-opts': isTopLevel
                ? baseSortOptions
                    |merge(craft.app.elementSources.getSourceSortOptions(elementType, key)|map(option => {
                        label: option.label,
                        attr: option.attribute ?? option.orderBy,
                        defaultDir: option.defaultDir ?? 'asc'
                    })|values)
                : false,
            'table-col-opts': isTopLevel
                ? tableColumns
                    |merge(craft.app.elementSources.getSourceTableAttributes(elementType, key))
                    |map((a, key) => a|merge({attr: key}))
                    |values
                : false,
            'default-table-cols': isTopLevel
                ? craft.app.elementSources.getTableAttributes(elementType, key)
                    |map(a => a[0])
                    |filter(a => a != 'title')
                    |values
                : false,
            'default-source-path': (source.defaultSourcePath ?? false) ? source.defaultSourcePath|json_encode : false,
            sites: (source.sites ?? false) ? source.sites|join(',') : false,
            'override-status': (source.criteria.status ?? false) ? true : false,
            disabled: source.disabled ?? false,
        }|merge(source.data ?? {}),
        html: _self.sourceInnerHtml(source)
    }) }}
{% endmacro %}

{% macro sourceInnerHtml(source) %}
    {% if source.status is defined %}
        <span class=\"status {{ source.status }}\"></span>
    {% elseif source.icon is defined %}
        <span class=\"icon\">
            {{ (svg(source.icon, sanitize=true, namespace=true) ?: \"<span data-icon='#{source.icon}'></span>\")|raw }}
        </span>
    {% elseif source.iconMask is defined %}
        <span class=\"icon icon-mask\">
            {{ (svg(source.iconMask, sanitize=true, namespace=true) ?: \"<span data-icon='#{source.iconMask}'></span>\")|raw }}
        </span>
    {% endif %}
    <span class=\"label\">{{ source.label|trim is not same as('') ? source.label : '(blank)'|t('app') }}</span>
    {% if source.badgeCount is defined %}
        <span class=\"badge\" aria-hidden=\"true\">{{ source.badgeCount|number(decimals=0) }}</span>
        {{ tag('span', {
            class: 'visually-hidden',
            data: {
                notification: true,
            },
            text: '{num, number} {num, plural, =1{notification} other{notifications}}'|t('app', {
                num: source.badgeCount,
            }),
        }) }}
    {% endif %}
{% endmacro %}

{% set nestedUnderHeading = false %}

{% tag 'ul' with {
    class: keyPrefix ? 'nested' : null,
} %}
    {% for source in sources %}
        {% if (source.type ?? null) == 'heading' %}
            {% if nestedUnderHeading %}
                    </ul>
                </li>
            {% endif %}
            <li class=\"heading\">
                <span>{{ source.heading|t('site') }}</span>
                <ul>
            {% set nestedUnderHeading = true %}
        {% else %}
            {% set key = source.keyPath ?? (keyPrefix ~ source.key) %}
            {% tag 'li' with {
                class: [
                    (source.disabled ?? false) ? 'hidden' : null,
                ]|filter,
            } %}
                {{ _self.sourceLink(key, source, isTopLevel, elementType, baseSortOptions ?? null, tableColumns ?? null) }}
                {% if source.nested is defined and source.nested is not empty %}
                    <button class=\"toggle\" aria-expanded=\"false\" aria-label=\"{{ 'Show nested sources'|t('app') }}\"></button>
                    {% include \"_elements/sources\" with {
                        keyPrefix: key ~ '/',
                        sources: source.nested
                    } %}
                {% endif %}
            {% endtag %}
        {% endif %}
    {% endfor %}
    {% if nestedUnderHeading %}
            </ul>
        </li>
    {% endif %}
{% endtag %}
{% endapply %}
", "_elements/sources", "/var/www/html/vendor/craftcms/cms/src/templates/_elements/sources.twig");
    }
}

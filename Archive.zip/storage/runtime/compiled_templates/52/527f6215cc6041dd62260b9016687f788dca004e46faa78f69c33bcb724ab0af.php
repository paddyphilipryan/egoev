<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* components/app */
class __TwigTemplate_fc0ed1df8c51c0fff366276bee346ecbf01277b5d1759ceb1dbe4af558a29ec6 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "components/app");
        craft\helpers\Template::preloadSingles(['entry']);
        // line 1
        echo "<!--=================================
      App -->
      <section class=\"space-p bg-light\">
        <div class=\"container\">
          <div class=\"row align-items-center\">
            <div class=\"col-lg-6 mt-5 mt-lg-0\">
              <div class=\"section-title left-divider\">
                <span>";
        // line 8
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 8, $this->source); })())), "appTitle", []), "html", null, true);
        echo "</span>
                <h2>";
        // line 9
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 9, $this->source); })())), "appMainHeading", []), "html", null, true);
        echo "</h2>
                <p>";
        // line 10
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 10, $this->source); })())), "appBodyText", []), "html", null, true);
        echo "</p>
              </div>
              <div class=\"d-block d-xs-flex mt-5\">
                  <a class=\"btn-app me-2\" href=\"";
        // line 13
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 13, $this->source); })())), "appIosLink", []), "html", null, true);
        echo "\">
                    <i class=\"fab fa-apple\"></i>
                    <div class=\"btn-text text-start\">
                      <small class=\"small-text\">Download on the </small>
                      <span class=\"mb-0 d-block\">App store</span>
                    </div>
                  </a>
                  <a class=\"btn-app\" href=\"";
        // line 20
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 20, $this->source); })())), "androidAppLink", []), "html", null, true);
        echo "\">
                    <i class=\"fab fa-google-play\"></i>
                    <div class=\"btn-text text-start\">
                      <small class=\"small-text\">Get in on </small>
                      <span class=\"mb-0 d-block\">google play</span>
                    </div>
                  </a>
                </div>
            </div>
            <div class=\"col-lg-6 text-center mt-4 mt-lg-5\">
              <img class=\"img-fluid\" src=\"images/home-03/mobile.png\" alt=\"\">
            </div>
          </div>
        </div>
      </section>
      <!--=================================
      App -->";
        craft\helpers\Template::endProfile("template", "components/app");
    }

    public function getTemplateName()
    {
        return "components/app";
    }

    public function getDebugInfo()
    {
        return array (  72 => 20,  62 => 13,  56 => 10,  52 => 9,  48 => 8,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!--=================================
      App -->
      <section class=\"space-p bg-light\">
        <div class=\"container\">
          <div class=\"row align-items-center\">
            <div class=\"col-lg-6 mt-5 mt-lg-0\">
              <div class=\"section-title left-divider\">
                <span>{{ entry.appTitle }}</span>
                <h2>{{ entry.appMainHeading }}</h2>
                <p>{{ entry.appBodyText }}</p>
              </div>
              <div class=\"d-block d-xs-flex mt-5\">
                  <a class=\"btn-app me-2\" href=\"{{ entry.appIosLink }}\">
                    <i class=\"fab fa-apple\"></i>
                    <div class=\"btn-text text-start\">
                      <small class=\"small-text\">Download on the </small>
                      <span class=\"mb-0 d-block\">App store</span>
                    </div>
                  </a>
                  <a class=\"btn-app\" href=\"{{ entry.androidAppLink }}\">
                    <i class=\"fab fa-google-play\"></i>
                    <div class=\"btn-text text-start\">
                      <small class=\"small-text\">Get in on </small>
                      <span class=\"mb-0 d-block\">google play</span>
                    </div>
                  </a>
                </div>
            </div>
            <div class=\"col-lg-6 text-center mt-4 mt-lg-5\">
              <img class=\"img-fluid\" src=\"images/home-03/mobile.png\" alt=\"\">
            </div>
          </div>
        </div>
      </section>
      <!--=================================
      App -->", "components/app", "/var/www/html/templates/components/app.twig");
    }
}

<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* components/hero */
class __TwigTemplate_c4087e96ff7170def31bf8d5b45e835aca35ea2b42bc3cee9dd85315551e2b04 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "components/hero");
        craft\helpers\Template::preloadSingles(['entry']);
        // line 1
        echo "<!--=================================
      Banner -->
      <section class=\"banner\">
        <div id=\"main-slider\" class=\"swiper-container\">
          <div class=\"slider-social\">
            <div class=\"container\">
              <div class=\"slider-social-info\">
                <ul class=\"list-unstyled mb-0\">
                  <li><a href=\"#\"> LinkedIn </a></li>
                  <li><a href=\"#\"> Instagram </a></li>
                  <li><a href=\"#\"> Facebook </a></li>
                  <li><span>Follow</span></li>
                </ul>
              </div>
            </div>
          </div>
          <div class=\"swiper-wrapper\">
            <div class=\"swiper-slide align-items-center d-flex slide-01\" style=\"background-image: url(images/home-01/banner-01.jpg); background-repeat: no-repeat; background-size: cover; background-position: center; z-index:1;\">
              <div class=\"container\">
                <div class=\"row\">
                  <div class=\"col-xl-7 col-lg-9 col-md-12 position-relative\">
                    <span class=\"banner-sub-title text-primary\" data-swiper-animation=\"fadeInUp\" data-duration=\"1.5s\" data-delay=\"0.5s\">";
        // line 22
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 22, $this->source); })())), "heroWelcome", []), "html", null, true);
        echo "</span>
                    <h1 class=\"text-white text-start\" data-swiper-animation=\"fadeInUp\" data-duration=\"1.5s\" data-delay=\"1.0s\">";
        // line 23
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 23, $this->source); })())), "heroTitle", []), "html", null, true);
        echo "</h1>
                    <a href=\"about-us.html\" class=\"btn btn-primary mt-3 mt-sm-5\" data-swiper-animation=\"fadeInUp\" data-duration=\"1.5s\" data-delay=\"2.0s\">";
        // line 24
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 24, $this->source); })())), "heroCta", []), "html", null, true);
        echo "</a>
                  </div>
                </div>
              </div>
            </div>
          <!-- Pagination -->
          <div class=\"container\">
            <div class=\"row\">
              <div class=\"col-lg-12 position-relative text-center\">
                <div class=\"pagination-button\">
                  <div class=\"swiper-button-prev\" tabindex=\"0\" role=\"button\" aria-label=\"Previous slide\">Prev</div>
                  <div class=\"swiper-button-next\" tabindex=\"0\" role=\"button\" aria-label=\"Next slide\">Next</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!--=================================
      Banner -->";
        craft\helpers\Template::endProfile("template", "components/hero");
    }

    public function getTemplateName()
    {
        return "components/hero";
    }

    public function getDebugInfo()
    {
        return array (  70 => 24,  66 => 23,  62 => 22,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!--=================================
      Banner -->
      <section class=\"banner\">
        <div id=\"main-slider\" class=\"swiper-container\">
          <div class=\"slider-social\">
            <div class=\"container\">
              <div class=\"slider-social-info\">
                <ul class=\"list-unstyled mb-0\">
                  <li><a href=\"#\"> LinkedIn </a></li>
                  <li><a href=\"#\"> Instagram </a></li>
                  <li><a href=\"#\"> Facebook </a></li>
                  <li><span>Follow</span></li>
                </ul>
              </div>
            </div>
          </div>
          <div class=\"swiper-wrapper\">
            <div class=\"swiper-slide align-items-center d-flex slide-01\" style=\"background-image: url(images/home-01/banner-01.jpg); background-repeat: no-repeat; background-size: cover; background-position: center; z-index:1;\">
              <div class=\"container\">
                <div class=\"row\">
                  <div class=\"col-xl-7 col-lg-9 col-md-12 position-relative\">
                    <span class=\"banner-sub-title text-primary\" data-swiper-animation=\"fadeInUp\" data-duration=\"1.5s\" data-delay=\"0.5s\">{{ entry.heroWelcome }}</span>
                    <h1 class=\"text-white text-start\" data-swiper-animation=\"fadeInUp\" data-duration=\"1.5s\" data-delay=\"1.0s\">{{ entry.heroTitle }}</h1>
                    <a href=\"about-us.html\" class=\"btn btn-primary mt-3 mt-sm-5\" data-swiper-animation=\"fadeInUp\" data-duration=\"1.5s\" data-delay=\"2.0s\">{{ entry.heroCta }}</a>
                  </div>
                </div>
              </div>
            </div>
          <!-- Pagination -->
          <div class=\"container\">
            <div class=\"row\">
              <div class=\"col-lg-12 position-relative text-center\">
                <div class=\"pagination-button\">
                  <div class=\"swiper-button-prev\" tabindex=\"0\" role=\"button\" aria-label=\"Previous slide\">Prev</div>
                  <div class=\"swiper-button-next\" tabindex=\"0\" role=\"button\" aria-label=\"Next slide\">Next</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!--=================================
      Banner -->", "components/hero", "/var/www/html/templates/components/hero.twig");
    }
}

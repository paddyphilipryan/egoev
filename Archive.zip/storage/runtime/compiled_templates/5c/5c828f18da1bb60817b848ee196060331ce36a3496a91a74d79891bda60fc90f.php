<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* serv/video */
class __TwigTemplate_f873e8f1bc2adfdb09e672ea02c5325c7ba9e6f8a670b7b47ac60b0a7f0e7e07 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "serv/video");
        // line 1
        echo "<!--=================================
      video -->
      <section class=\"bg-overlay-black-2 bg-holder video-bg-section\" style=\"background-image: url(./images/home-03/bg-01.jpg);\">
        <div class=\"video-wrapper\">
          <video autoplay muted loop playsinline preload=\"metadata\">
            <source src=\"images/bg/bg-video.mp4\" type=\"video/mp4\">
          </video>
        </div>
      </section>
      <!--=================================
      video -->";
        craft\helpers\Template::endProfile("template", "serv/video");
    }

    public function getTemplateName()
    {
        return "serv/video";
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!--=================================
      video -->
      <section class=\"bg-overlay-black-2 bg-holder video-bg-section\" style=\"background-image: url(./images/home-03/bg-01.jpg);\">
        <div class=\"video-wrapper\">
          <video autoplay muted loop playsinline preload=\"metadata\">
            <source src=\"images/bg/bg-video.mp4\" type=\"video/mp4\">
          </video>
        </div>
      </section>
      <!--=================================
      video -->", "serv/video", "/var/www/html/templates/serv/video.twig");
    }
}

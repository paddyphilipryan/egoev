<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* components/accordian */
class __TwigTemplate_b2e5fccbacc8bb2798e1da477d0ec5d1410a366a45d391e7e272c90951955761 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "components/accordian");
        craft\helpers\Template::preloadSingles(['entry', 'faq']);
        // line 1
        echo "<!--=================================
      accordion -->
      <section class=\"space-ptb bg-light map-section\">
        <div class=\"container\">
          <div class=\"row align-items-center\">
            <div class=\"col-md-12 col-lg-6\">
              <div class=\"d-flex fle flex-column\">
                <div class=\"section-title left-divider order-last order-lg-first\">
                  <span>FAQ</span>
                  <h2>";
        // line 10
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 10, $this->source); })())), "faqTitle", []), "html", null, true);
        echo "</h2>
                </div>
                <div class=\"map-listing order-frist order-lg-last\">
                  <img class=\"img-fluid\" src=\"images/home-03/bg-13.png\" alt=\"#\">
                </div>
              </div>
            </div>
            <div class=\"col-md-12 col-lg-6\">
            ";
        // line 18
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 18, $this->source); })())), "faqMatrix", []), "all", [], "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["faq"]) {
            // line 19
            echo "              <div class=\"accordion\" id=\"accordionExample\">
                <div class=\"accordion-item\">
                  <h3 class=\"accordion-header\">
                  <button class=\"accordion-button\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#collapseTwo\" aria-expanded=\"true\" aria-controls=\"collapseTwo\">";
            // line 22
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["faq"], "question", []), "html", null, true);
            echo "</button>
                  </h3>
                  <div id=\"collapseTwo\" class=\"accordion-collapse collapse \" aria-labelledby=\"headingTwo\" data-bs-parent=\"#accordionExample\">
                    <div class=\"accordion-body\">
                      ";
            // line 26
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["faq"], "answer", []), "html", null, true);
            echo "
                    </div>
                  </div>
                </div>
              </div>
             ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['faq'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "            </div>
          </div>
        </div>
      </section>
      <!--=================================
      accordion -->
";
        craft\helpers\Template::endProfile("template", "components/accordian");
    }

    public function getTemplateName()
    {
        return "components/accordian";
    }

    public function getDebugInfo()
    {
        return array (  89 => 32,  77 => 26,  70 => 22,  65 => 19,  61 => 18,  50 => 10,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!--=================================
      accordion -->
      <section class=\"space-ptb bg-light map-section\">
        <div class=\"container\">
          <div class=\"row align-items-center\">
            <div class=\"col-md-12 col-lg-6\">
              <div class=\"d-flex fle flex-column\">
                <div class=\"section-title left-divider order-last order-lg-first\">
                  <span>FAQ</span>
                  <h2>{{ entry.faqTitle }}</h2>
                </div>
                <div class=\"map-listing order-frist order-lg-last\">
                  <img class=\"img-fluid\" src=\"images/home-03/bg-13.png\" alt=\"#\">
                </div>
              </div>
            </div>
            <div class=\"col-md-12 col-lg-6\">
            {% for faq in entry.faqMatrix.all() %}
              <div class=\"accordion\" id=\"accordionExample\">
                <div class=\"accordion-item\">
                  <h3 class=\"accordion-header\">
                  <button class=\"accordion-button\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#collapseTwo\" aria-expanded=\"true\" aria-controls=\"collapseTwo\">{{faq.question}}</button>
                  </h3>
                  <div id=\"collapseTwo\" class=\"accordion-collapse collapse \" aria-labelledby=\"headingTwo\" data-bs-parent=\"#accordionExample\">
                    <div class=\"accordion-body\">
                      {{faq.answer}}
                    </div>
                  </div>
                </div>
              </div>
             {% endfor %}
            </div>
          </div>
        </div>
      </section>
      <!--=================================
      accordion -->
", "components/accordian", "/var/www/html/templates/components/accordian.twig");
    }
}

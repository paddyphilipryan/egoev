<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* components/clients */
class __TwigTemplate_0e45625901683fe2f1aa88f10db5c0377091d0975004f1a2cac43e62ea0236b0 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "components/clients");
        craft\helpers\Template::preloadSingles(['entry', 'image', 'dark', 'light']);
        // line 1
        echo "<!--=================================
      clients -->
      <section class=\"clients-section bg-light\">
        <div class=\"container\">
          <div class=\"row\">
            <div class=\"owl-carousel owl-nav-bottom-center p-0\" data-nav-dots=\"false\" data-nav-arrow=\"false\" data-items=\"4\" data-lg-items=\"4\" data-md-items=\"3\" data-sm-items=\"2\"  data-space=\"30\" data-autoheight=\"true\">
              ";
        // line 7
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 7, $this->source); })())), "carLogos", []), "all", [], "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["image"]) {
            // line 8
            echo "              ";
            $context["dark"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["image"], "logoDark", []), "one", [], "method");
            echo " 
              ";
            // line 9
            $context["light"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["image"], "logoLight", []), "one", [], "method");
            echo "   
              <div class=\"item\">
                <div class=\"client-box\">
                  
                  <div class=\"client-hover-img\">
                    <a href=\"#\"><img class=\"img-fluid\" src=\"";
            // line 14
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["dark"]) || array_key_exists("dark", $context) ? $context["dark"] : (craft\helpers\Template::fallbackExists("dark") ? craft\helpers\Template::fallback("dark") : (function () { throw new RuntimeError('Variable "dark" does not exist.', 14, $this->source); })())), "url", []), "html", null, true);
            echo "\" alt=\"#\"></a>
                  </div>
                  <div class=\"client-img\">
                    <a href=\"#\"><img class=\"img-fluid\" src=\"";
            // line 17
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["light"]) || array_key_exists("light", $context) ? $context["light"] : (craft\helpers\Template::fallbackExists("light") ? craft\helpers\Template::fallback("light") : (function () { throw new RuntimeError('Variable "light" does not exist.', 17, $this->source); })())), "url", []), "html", null, true);
            echo "\" alt=\"#\"></a>
                  </div>

                </div>
              </div>
              ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['image'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 23
        echo "            </div>
          </div>
        </div>
      </section>
      <!--=================================
      clients -->";
        craft\helpers\Template::endProfile("template", "components/clients");
    }

    public function getTemplateName()
    {
        return "components/clients";
    }

    public function getDebugInfo()
    {
        return array (  82 => 23,  70 => 17,  64 => 14,  56 => 9,  51 => 8,  47 => 7,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!--=================================
      clients -->
      <section class=\"clients-section bg-light\">
        <div class=\"container\">
          <div class=\"row\">
            <div class=\"owl-carousel owl-nav-bottom-center p-0\" data-nav-dots=\"false\" data-nav-arrow=\"false\" data-items=\"4\" data-lg-items=\"4\" data-md-items=\"3\" data-sm-items=\"2\"  data-space=\"30\" data-autoheight=\"true\">
              {% for image in entry.carLogos.all() %}
              {% set dark = image.logoDark.one() %} 
              {% set light = image.logoLight.one() %}   
              <div class=\"item\">
                <div class=\"client-box\">
                  
                  <div class=\"client-hover-img\">
                    <a href=\"#\"><img class=\"img-fluid\" src=\"{{ dark.url }}\" alt=\"#\"></a>
                  </div>
                  <div class=\"client-img\">
                    <a href=\"#\"><img class=\"img-fluid\" src=\"{{ light.url }}\" alt=\"#\"></a>
                  </div>

                </div>
              </div>
              {% endfor %}
            </div>
          </div>
        </div>
      </section>
      <!--=================================
      clients -->", "components/clients", "/var/www/html/templates/components/clients.twig");
    }
}

<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* globals/footer */
class __TwigTemplate_2e341f6bb389719231da361d12d3127d2d272d4c2d70c26743ed2ab8ef7a38d4 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "globals/footer");
        craft\helpers\Template::preloadSingles(['siteUrl', 'header', 'logod']);
        // line 1
        echo "<!--=================================
      footer-->
      <footer class=\"footer space-pt bg-overlay-secondary-9 bg-holder\" style=\"background-image: url(";
        // line 3
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (craft\helpers\Template::fallbackExists("siteUrl") ? craft\helpers\Template::fallback("siteUrl") : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 3, $this->source); })())), "html", null, true);
        echo "images/home-01/footer-bg.jpg);\">
        <div class=\"container position-relative pb-5\">
          <div class=\"row\">
            <div class=\"col-sm-6 col-lg-3 mb-4 mb-lg-0\">
                  ";
        // line 7
        $context["logol"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["header"]) || array_key_exists("header", $context) ? $context["header"] : (craft\helpers\Template::fallbackExists("header") ? craft\helpers\Template::fallback("header") : (function () { throw new RuntimeError('Variable "header" does not exist.', 7, $this->source); })())), "logoLight", []), "one", [], "method");
        // line 8
        echo "                  ";
        $context["logod"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["header"]) || array_key_exists("header", $context) ? $context["header"] : (craft\helpers\Template::fallbackExists("header") ? craft\helpers\Template::fallback("header") : (function () { throw new RuntimeError('Variable "header" does not exist.', 8, $this->source); })())), "logoDark", []), "one", [], "method");
        // line 9
        echo "  
              <div class=\"footer-logo mb-3 mb-md-5\">
                <img class=\"logo img-fluid\" src=\"";
        // line 11
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["logod"]) || array_key_exists("logod", $context) ? $context["logod"] : (craft\helpers\Template::fallbackExists("logod") ? craft\helpers\Template::fallback("logod") : (function () { throw new RuntimeError('Variable "logod" does not exist.', 11, $this->source); })())), "url", []), "html", null, true);
        echo "\" alt=\"logo\">
              </div>
              <div class=\"call-center\">
                <h3>Call Us: ";
        // line 14
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["header"]) || array_key_exists("header", $context) ? $context["header"] : (craft\helpers\Template::fallbackExists("header") ? craft\helpers\Template::fallback("header") : (function () { throw new RuntimeError('Variable "header" does not exist.', 14, $this->source); })())), "navPhone", []), "html", null, true);
        echo "</h3>
              </div>
              <div class=\"footer-social-icon\">
                <ul class=\"list-unstyled mb-0\">
                  <li><a href=\"#\"><i class=\"fab fa-facebook-f\"></i></a></li>
                  <li><a href=\"#\"><i class=\"fab fa-instagram\"></i></a></li>
                  <li><a href=\"#\"><i class=\"fab fa-twitter\"></i></a></li>
                  <li><a href=\"#\"><i class=\"fab fa-dropbox\"></i></a></li>
                </ul>
              </div>
            </div>
            <div class=\"col-lg-8  mb-4 mb-lg-0\">
              <div class=\"footer-newsletter\">
                <h3 class=\"text-white\">Signup for our newsletter </h3>
                <p>Sign up to our newsletter to get the latest news and offers.</p>
                <form class=\"form-inline dark-form\">
                  <div class=\"form-group\">
                    <input type=\"text\" class=\"form-control\" placeholder=\"Enter email for newsletter\">
                  </div>
                  <button type=\"submit\" class=\"btn btn-primary\">Subscribe <i class=\"fa-solid fa-arrow-right-long ms-2\"></i></button>
                </form>
              </div>
            </div>
          </div>
        </div>
        <div class=\"container position-relative\">
          <div class=\"copyright\">
            <div class=\"row d-flex align-items-center\">
              <div class=\"col-md-12 text-center\">
                <p class=\"mb-0 text-white\">";
        // line 43
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["header"]) || array_key_exists("header", $context) ? $context["header"] : (craft\helpers\Template::fallbackExists("header") ? craft\helpers\Template::fallback("header") : (function () { throw new RuntimeError('Variable "header" does not exist.', 43, $this->source); })())), "footerCopy", []), "html", null, true);
        echo "</p>
              </div>
            </div>
          </div>
        </div>
      </footer>
      <!--=================================
      footer-->";
        craft\helpers\Template::endProfile("template", "globals/footer");
    }

    public function getTemplateName()
    {
        return "globals/footer";
    }

    public function getDebugInfo()
    {
        return array (  97 => 43,  65 => 14,  59 => 11,  55 => 9,  52 => 8,  50 => 7,  43 => 3,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!--=================================
      footer-->
      <footer class=\"footer space-pt bg-overlay-secondary-9 bg-holder\" style=\"background-image: url({{ siteUrl }}images/home-01/footer-bg.jpg);\">
        <div class=\"container position-relative pb-5\">
          <div class=\"row\">
            <div class=\"col-sm-6 col-lg-3 mb-4 mb-lg-0\">
                  {% set logol = header.logoLight.one() %}
                  {% set logod = header.logoDark.one() %}
  
              <div class=\"footer-logo mb-3 mb-md-5\">
                <img class=\"logo img-fluid\" src=\"{{ logod.url }}\" alt=\"logo\">
              </div>
              <div class=\"call-center\">
                <h3>Call Us: {{ header.navPhone }}</h3>
              </div>
              <div class=\"footer-social-icon\">
                <ul class=\"list-unstyled mb-0\">
                  <li><a href=\"#\"><i class=\"fab fa-facebook-f\"></i></a></li>
                  <li><a href=\"#\"><i class=\"fab fa-instagram\"></i></a></li>
                  <li><a href=\"#\"><i class=\"fab fa-twitter\"></i></a></li>
                  <li><a href=\"#\"><i class=\"fab fa-dropbox\"></i></a></li>
                </ul>
              </div>
            </div>
            <div class=\"col-lg-8  mb-4 mb-lg-0\">
              <div class=\"footer-newsletter\">
                <h3 class=\"text-white\">Signup for our newsletter </h3>
                <p>Sign up to our newsletter to get the latest news and offers.</p>
                <form class=\"form-inline dark-form\">
                  <div class=\"form-group\">
                    <input type=\"text\" class=\"form-control\" placeholder=\"Enter email for newsletter\">
                  </div>
                  <button type=\"submit\" class=\"btn btn-primary\">Subscribe <i class=\"fa-solid fa-arrow-right-long ms-2\"></i></button>
                </form>
              </div>
            </div>
          </div>
        </div>
        <div class=\"container position-relative\">
          <div class=\"copyright\">
            <div class=\"row d-flex align-items-center\">
              <div class=\"col-md-12 text-center\">
                <p class=\"mb-0 text-white\">{{ header.footerCopy }}</p>
              </div>
            </div>
          </div>
        </div>
      </footer>
      <!--=================================
      footer-->", "globals/footer", "/var/www/html/templates/globals/footer.twig");
    }
}

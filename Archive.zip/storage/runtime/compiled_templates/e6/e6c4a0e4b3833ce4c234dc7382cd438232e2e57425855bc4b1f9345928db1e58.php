<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home.twig */
class __TwigTemplate_7b231675fbd684b19194519b97985369022f525b62758c3bc51876145eedbc3b extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "index";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "home.twig");
        $this->parent = $this->loadTemplate("index", "home.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "home.twig");
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 4
        echo "<!--==== Main content START -->
";
        // line 5
        $this->loadTemplate("components/hero", "home.twig", 5)->display($context);
        echo "\t
";
        // line 6
        $this->loadTemplate("components/clients", "home.twig", 6)->display($context);
        echo " 
";
        // line 7
        $this->loadTemplate("components/services2", "home.twig", 7)->display($context);
        echo " 
";
        // line 8
        $this->loadTemplate("components/banner", "home.twig", 8)->display($context);
        echo " 
";
        // line 9
        $this->loadTemplate("components/services", "home.twig", 9)->display($context);
        echo " 
";
        // line 10
        $this->loadTemplate("components/accordian", "home.twig", 10)->display($context);
        echo " 
";
        // line 11
        $this->loadTemplate("serv/video", "home.twig", 11)->display($context);
        echo " 
";
        // line 12
        $this->loadTemplate("components/blog", "home.twig", 12)->display($context);
        echo " 
";
        // line 13
        $this->loadTemplate("components/test1", "home.twig", 13)->display($context);
        echo " 
";
        // line 14
        $this->loadTemplate("components/app", "home.twig", 14)->display($context);
        echo "  
      
 ";
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "home.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  92 => 14,  88 => 13,  84 => 12,  80 => 11,  76 => 10,  72 => 9,  68 => 8,  64 => 7,  60 => 6,  56 => 5,  53 => 4,  48 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"index\" %}

{% block content %}
<!--==== Main content START -->
{% include \"components/hero\" %}\t
{% include \"components/clients\" %} 
{% include \"components/services2\" %} 
{% include \"components/banner\" %} 
{% include \"components/services\" %} 
{% include \"components/accordian\" %} 
{% include \"serv/video\" %} 
{% include \"components/blog\" %} 
{% include \"components/test1\" %} 
{% include \"components/app\" %}  
      
 {% endblock %} ", "home.twig", "/var/www/html/templates/home.twig");
    }
}

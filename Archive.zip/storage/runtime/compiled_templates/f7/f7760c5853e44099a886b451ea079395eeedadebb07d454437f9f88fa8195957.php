<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* components/services2 */
class __TwigTemplate_58ae475163b2c30748fb799c0bb7443d897bd953799f8654db692d5887177dff extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "components/services2");
        craft\helpers\Template::preloadSingles(['entry', 'services', 'photo']);
        // line 1
        echo "<!--=================================
      Our Services-->
      <section class=\"space-ptb\">
        <div class=\"container\">
          <div class=\"row d-flex align-items-center\">
            <div class=\"col-lg-6\">
              <div class=\"section-title left-divider mb-0\">
                <span>";
        // line 8
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 8, $this->source); })())), "servicesSubtitle", []), "html", null, true);
        echo "</span>
                <h2>";
        // line 9
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 9, $this->source); })())), "servicesTitle", []), "html", null, true);
        echo "</h2>
              </div>
            </div>
            <div class=\"col-lg-6 text-start text-lg-end mt-4 mt-lg-0\">
              <a href=\"#\" class=\"btn btn-primary\">";
        // line 13
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 13, $this->source); })())), "servicesCtaText", []), "html", null, true);
        echo "</a>
            </div>
          </div>
          <div class=\"row mt-5\">
           ";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["entry"]) || array_key_exists("entry", $context) ? $context["entry"] : (craft\helpers\Template::fallbackExists("entry") ? craft\helpers\Template::fallback("entry") : (function () { throw new RuntimeError('Variable "entry" does not exist.', 17, $this->source); })())), "servicesEntries", []), "all", [], "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["services"]) {
            // line 18
            echo "           ";
            $context["photo"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, $context["services"], "serviceImage", []), "one", [], "method");
            echo "  
            <div class=\"col-md-12 col-lg-6\">
              <div class=\"service-item service-info-style-01\">
                <div class=\"service-img\">
                  <div class=\"service-img-inner\">
                    <img class=\"img-fluid\" src=\"";
            // line 23
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["photo"]) || array_key_exists("photo", $context) ? $context["photo"] : (craft\helpers\Template::fallbackExists("photo") ? craft\helpers\Template::fallback("photo") : (function () { throw new RuntimeError('Variable "photo" does not exist.', 23, $this->source); })())), "url", []), "html", null, true);
            echo "\" alt=\"\">
                  </div>
                </div>
                <div class=\"service-content\">
                  <h3 class=\"service-title\">";
            // line 27
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["services"], "serviceTitle", []), "html", null, true);
            echo "</h3>
                  <p>";
            // line 28
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["services"], "serviceDescription", []), "html", null, true);
            echo "</p>
                  <a href=\"charging-network-operators.html\">";
            // line 29
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["services"], "serviceTextLinkTitle", []), "html", null, true);
            echo "<i class=\"fa-solid fa-arrow-right-long ps-2\"></i></a>
                </div>
              </div>
            </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['services'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 34
        echo "          </div>
        </div>
      </section> ";
        craft\helpers\Template::endProfile("template", "components/services2");
    }

    public function getTemplateName()
    {
        return "components/services2";
    }

    public function getDebugInfo()
    {
        return array (  105 => 34,  94 => 29,  90 => 28,  86 => 27,  79 => 23,  70 => 18,  66 => 17,  59 => 13,  52 => 9,  48 => 8,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!--=================================
      Our Services-->
      <section class=\"space-ptb\">
        <div class=\"container\">
          <div class=\"row d-flex align-items-center\">
            <div class=\"col-lg-6\">
              <div class=\"section-title left-divider mb-0\">
                <span>{{ entry.servicesSubtitle }}</span>
                <h2>{{ entry.servicesTitle }}</h2>
              </div>
            </div>
            <div class=\"col-lg-6 text-start text-lg-end mt-4 mt-lg-0\">
              <a href=\"#\" class=\"btn btn-primary\">{{ entry.servicesCtaText }}</a>
            </div>
          </div>
          <div class=\"row mt-5\">
           {% for services in entry.servicesEntries.all() %}
           {% set photo = services.serviceImage.one() %}  
            <div class=\"col-md-12 col-lg-6\">
              <div class=\"service-item service-info-style-01\">
                <div class=\"service-img\">
                  <div class=\"service-img-inner\">
                    <img class=\"img-fluid\" src=\"{{ photo.url }}\" alt=\"\">
                  </div>
                </div>
                <div class=\"service-content\">
                  <h3 class=\"service-title\">{{services.serviceTitle}}</h3>
                  <p>{{services.serviceDescription}}</p>
                  <a href=\"charging-network-operators.html\">{{services.serviceTextLinkTitle}}<i class=\"fa-solid fa-arrow-right-long ps-2\"></i></a>
                </div>
              </div>
            </div>
            {% endfor %}
          </div>
        </div>
      </section> ", "components/services2", "/var/www/html/templates/components/services2.twig");
    }
}
